# Scientific coverage map

Case indices are zero-based. Inline targets are analytically derived or
independently recomputed; no target calls the candidate being graded.

| Public behavior | Cases | Independent basis and significance |
|---|---|---|
| Clamped work, engineering shear, zero strain and reversal | Step 1: 0–3,6–7 | Work-conjugate stress and quadratic homogeneity; detects missing coupling or wrong shear normalization. |
| Free transverse contraction / auxetic expansion | Step 1: 8–10 | Analytic stationarity and relaxed uniaxial curvature; distinguishes clamped stiffness from Young modulus. |
| Full-free equilibrium, restricted stability, minimality | Step 1: 11–13,16,18,20 | Positive free principal minors, Schur complement and nonnegative perturbation work; detects a global-stability shortcut or rounded singular pivot. |
| Strict small-positive free curvature and formal large relaxation | Step 1: 15,17,19–20 | Exact constrained special cases; rejects arbitrary soft-mode cutoffs or clipping relaxed outputs. |
| Finite shapes, ranges, free labels, empty batches | Step 1: 2,4–6,11,13–14 | Explicit input/output contracts; ignored guesses must still be valid. |
| Exact / noisy least squares, scaling, no intercept or positivity constraint | Step 2: 0–1,3,6,16–17,20–21 | Analytic material tensors, QR orthogonality and independent minimizer; preserves unstable curvature. |
| Data admissibility and unscaled physical design | Step 2: 2,4–5,7–9,18–19 | Quadratic identifiability, finite positive area, shape and rank rules. |
| RMS and conditioning boundary decisions | Step 2: 10–15,22–23 | Exact RMS endpoint and analytic Gram eigenvalues; cond2=1000 is included to numerical precision. |
| Isotropic / auxetic tensor projection, reciprocity and scaling | Step 3: 0–4,10–11,13 | Independent uniaxial stress/strain tensor and isotropic identities; engineering shear and Poisson sign. |
| Strict Born conditions, positive soft shear and small determinant | Step 3: 5–9,12 | Separate diagonal/determinant failures and analytic / high-precision special cases. |
| Nearly soft normal block at its hard loading direction | Step 3: 14–15; Step 4: 18 | 90-digit direct stress solves and independent positive modal work; cancellation-sensitive yet physically admissible. |
| Final result fields, unstable NaNs, shapes and validation | Step 4: 0–4,11–13; general: 9 | Public nine-key dictionary, Python scalar types, returned-fit phase branch. |
| Continuous global extrema and sample-grid independence | Step 4: 5–7,9; general: 3–5,7 | Rational oblique stationary directions, derivative root search and continuum bounds; rejects sampled extrema. |
| Returned-fit error propagation in isotropic / soft-shear regimes | Step 4: 8,10,14,18; general: 6,8 | Independent response and canonical geometry at returned coefficients; accepts admissible fit perturbations. |
| Exact-zero Born boundaries and small-positive determinant | Step 4: 13–15 | Zero-shear and zero-determinant source datasets fitted end to end; strict classification checked at their returned tensors. |
| Non-isotropic canonical ties | Step 4: 16–17 | Analytic endpoint E values, soft or stiff shear, relative gaps 0,0.8e-10,1.2e-10; choose smaller angle only within stated tie scale. |

All absolute-plus-relative tolerances appear in the visible prompts. Direct
energy, strain, stress, coefficient, E, and Poisson assertions use their own
budgets. Derived ratios and perturbation identities either use independently
known targets or propagate all participating errors. Final mechanics are
checked at the returned fit, where stability and directions are defined.

The author-side runners additionally check admissible intermediate-error
perturbations, six focused boundary-error controls, repeat numerical processes,
80 deterministic material/design pairs, and 2,268 high-precision directions.
These checks support the numerical regime without exposing their specific
inputs in agent-visible scientific descriptions.
