# Public-contract coverage and target provenance

Case numbers are zero-based within each `tests/*.py` file. All expectations are
inline; no stored HDF5 targets are used, so no stored-target `target_evidence`
records are applicable. Each parser case repeats its imports and inputs.

## Accuracy budgets

Numerical comparisons use absolute-plus-relative tolerances. Energy uses
atol 1e-12 eV/Angstrom² and rtol 1e-10. Exact stiffness uses atol 1e-5 N/m and
rtol 1e-8; noisy stiffness uses atol 1e-4 N/m and rtol 1e-5 against the **OLS
minimizer**, not the unknown noise-free tensor. Directional quantities at an
identical tensor use E atol 1e-8 N/m, rtol 1e-9 and nu atol 1e-10, rtol 1e-9.

Integrated comparisons to an underlying, comfortably stable tensor allow
E atol 1e-4 N/m, rtol 1e-5 and nu atol 1e-6, rtol 1e-5. This accounts for
fit-error propagation. Tighter directional checks use the candidate's own
returned tensor and an independently implemented tensor projection. The
nearly soft regime is checked this way rather than assuming a uniformly small
forward error from every stiffness perturbation. Critical angles use atol and
rtol 1e-7; the public relative-modulus tie threshold is 1e-10.

## Step 1: harmonic areal energy — 8 cases

| Behavior / scientific role | Cases | Independent basis | Errors detected |
|---|---|---|---|
| Normal and mixed loading; coupling sign and unit conversion | 0, 3, 7 | Work-conjugate stress integrated from zero strain | Missing C12, incorrect eV conversion |
| Engineering pure shear | 1, 3, 6, 7 | Half stress times engineering strain | Factor-of-two or tensor-shear confusion |
| Zero strain; reversal symmetry; quadratic homogeneity | 3, 7 | Homogeneous even quadratic energy | Offset, odd-strain contamination, nonlinear scaling |
| Included +3% / -3% strain endpoints | 2, 6 | Same analytic energy evaluated at endpoints | Incorrect strict bound or clipping |
| Exact batch output shape, floating array, empty batch | 3, 6, 7 | Public batch contract | Broadcasting, singleton output axis |
| Unstable curvature is permitted | 6 | Negative energy along negative stiffness modes | Unrequested stability constraint |
| Nonfinite strains or stiffness | 4 | Explicit ValueError contract; both NaN and infinity | Missing finiteness checks |
| Stiffness exactly (4,); strain exactly (M,3); strain range | 2, 5 | Explicit ValueError contract | Flattening, wrong coefficient count, invalid strains |

Six of eight cases compute scientific outputs, rather than checking only errors.

## Step 2: stiffness inference — 22 cases

| Behavior / scientific role | Cases | Independent basis | Errors detected |
|---|---|---|---|
| Isotropic stiffness and multiple anisotropic/auxetic regimes | 0, 3, 6, 10–12, 14, 17 | Synthetic data generated from a known tensor | Wrong ordering, sign, shear factor, units |
| Noisy ordinary least squares | 1, 16, 21 | Independent reduced QR projection | Wrong weighting, fitting intercept, non-OLS estimator |
| No intercept; numerical odd-energy noise cancels for +/- pairs | 16, 20 | QR target; quadratic columns even while noise is odd | Baseline removal, unwanted linear terms |
| Fixed unstrained area; supercell extensivity | 6 | Area and energy scaled together | Area omission or incorrect normalization |
| (4,) floating output; M=4 allowed | 3, 12 | Identifiable minimal design | Wrong output shape; unnecessary sample minimum |
| RMS threshold accepts approximately 2e-6 and exactly 1e-6 | 10, 12 | Direct raw-column RMS calculation | Invented 1e-5 cutoff; strict endpoint exclusion |
| RMS just below 1e-6 rejects despite good conditioning | 13 | Raw shear-column RMS approximately 0.99e-6 | Normalizing columns to hide insufficient signal |
| Raw condition number in (100,1000), and approximately 999 allowed | 11, 14 | Independently measured singular values | Invented 100 cutoff |
| Raw condition approximately 1001 and nearly collinear designs reject | 5, 15 | Singular spectrum of full-rank physical design | Missing or excessive conditioning tolerance |
| Rank deficiency, including all columns nonzero | 2, 19 | Dependent quadratic columns | Treating signal strength as identifiability |
| Negative stiffness and coupling retained | 3, 10, 12, 14, 17 | Known signed quadratic curvature | Positivity-constrained fit or clipping |
| Energy count/shape and finiteness | 7, 8, 18 | Explicit input contract | Broadcasting, NaN/inf acceptance |
| Area scalar, positive, finite | 9, 18 | Explicit input contract | Zero/negative/nonfinite/nonscalar normalization |
| Strain shape/range/finiteness; fewer than four rows | 18 | Explicit input contract | Malformed or insufficient observations |

Twelve of twenty-two cases recover scientific stiffness values. The threshold
rejection cases also check physically meaningful resolvability/conditioning.

## Step 3: directional mechanics — 14 cases

| Behavior / scientific role | Cases | Independent basis | Errors detected |
|---|---|---|---|
| Isotropic rotational invariance and isotropic auxetic limit | 0, 4 | E, nu material parameters | Shear-factor error, Poisson sign |
| Anisotropic angular response; E/nu output shapes and floating arrays | 1, 11 | Direct 3x3 stress solve and explicit 2x2 tensor projection | Incorrect rotation, engineering/tensor shear confusion |
| Principal-axis response and Poisson reciprocity | 2, 8, 10 | Normal-block compliance identities | Coefficient order, reciprocal coupling error |
| Reflection, pi-periodicity, negative/multiple-period angles | 10 | Orthotropic symmetry | Sorting, folding or permuting outputs |
| Near-soft positive normal determinant | 2, 8, 12 | Principal-axis identities; 90-digit direct stress solve | Arbitrary determinant cutoff; unstable inversion |
| Positive shear 1e-6 N/m under oblique loading | 9 | Analytic axial/transverse compliance at pi/4 | Small-positive-shear cutoff; shear omission |
| Material-scale covariance | 13 | E scales; nu remains dimensionless | Missing normalization or dimension error |
| Full Born positivity, determinant zero/negative, C66 zero/negative | 3, 7 | Positive definiteness of separate normal and shear blocks | Determinant-only stability test |
| Nonfinite or malformed stiffness and angles; empty directions | 5, 6 | Explicit ValueError contract | Missing independent input validation |

Ten of fourteen cases compute directional scientific results. Case 12's targets
come from a 90-decimal-digit tensor stress solve at the exact represented float
inputs; it does not use the reference's closed scalar compliance expressions.

## Step 4: integrated result — 13 cases

| Behavior / scientific role | Cases | Independent basis | Errors detected |
|---|---|---|---|
| Stable dict keys, array shapes, Python bool, all five Python floats | 0, 4, 12 | Explicit public result contract | Missing/extra keys; NumPy scalar summaries |
| Principal-axis anisotropy and auxetic material | 0, 2 | Analytic normal-block identities | Inverted ratio, wrong signs |
| Oblique global minimum, absent from two principal-axis samples | 5 | Rational compliance stationary point cos²(theta)=14/31 | Sample-only extrema |
| Oblique global maximum, absent from principal-axis samples | 6 | Independently derived rational stationary point | Endpoint-only optimization |
| Single/sparse/permuted angle grids give same global summaries | 7 | Material extrema independent of requested sampling | Grid-dependent anisotropy |
| Isotropic extrema and canonical numerical tie handling | 8 | Constant E and nu | Roundoff-selected arbitrary direction |
| Noisy fit, response at returned tensor, attained global extrema | 9 | QR fit; direct stress solves; independent dense-grid bounds | Fit/response inconsistency; hidden tolerance mismatch |
| Tiny positive shear remains stable | 10 | Known positive tensor and oblique compliance | Numerical stability cutoff |
| Unstable tensors retain fit, NaN arrays, NaN Python scalars | 1, 4, 12 | Full Born rules; small negative shear identified by decoupled observations | Determinant-only classification; clipping; calling unstable solver |
| Invalid angles in BOTH stable and unstable branches | 3 | Explicit input contract | Skipping validation when returning NaN |
| Invalid fitting inputs through the final interface | 11 | Step-2 public constraints | Silently repairing/broadcasting energy or area |

Eleven of thirteen cases produce scientifically interpreted outputs; instability
classification is a meaningful material result, not an invalid-input test.

## Whole-task results — 10 cases

`tests/general.py` calls only the final interface from complete solutions:
0 isotropic; 1 deterministic noisy anisotropy; 2 auxetic principal axes;
3 oblique global minimum; 4 oblique global maximum; 5 sampling independence;
6 isotropic tie convention; 7 fit/response consistency under noise;
8 small-positive-shear stability; 9 separate Born-instability branches.
The whole-task shear mutant is rejected by eight integrated cases.

## Verification limits

These cases do not exhaust a continuous parameter domain. The tensor derivation,
analytic limits, 80 deterministic author-side stress cases, and two numerical
methods support the stated calibrated range. External model rollouts, an exploit
probe, a difficulty score, the current upload parser, and human approval have not
been run here. They cannot be inferred from local numerical success.
