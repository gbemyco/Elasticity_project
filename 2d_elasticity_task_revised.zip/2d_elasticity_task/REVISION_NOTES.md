# Revision record

This revision addresses the findings in the supplied content-check notebook.
The existing task identity is retained, and the task still has four steps.

| Finding | Cause and repair | Regression / label |
|---|---|---|
| Step 1 is a short energy transcription | Replace scalar substitution with mixed prescribed/free elastic relaxation. Require positive curvature only in the free block and return equilibrium, stress, and energy. Update signature, dependencies and all interfaces. | Step 1 cases 8–20; difficulty_increase, repair |
| Conditioning endpoint 1000 absent | Derive an endpoint dataset from an independent analytic design-Gram eigensystem; explicitly include a 64-epsilon roundoff allowance in the public design thresholds. | Step 2 cases 22–23; grading_fix |
| Exact-zero integrated Born branches absent | Verify classification at exact fitted zero shear and zero determinant through the required public fitting dependency, with end-to-end fitting checked separately. Avoid treating a rounded source tensor as an exact fitted boundary. | Step 4 cases 13–15, 18; robustness, grading_fix |
| Hidden positive determinant cutoff can pass | Include a positive normal determinant ratio near 1.49e-8, and compare directional responses at the returned tensor using independent stress/eigenmode work. | Step 3 cases 8,12,14,15; Step 4 cases 14,15,18; robustness |
| Only isotropic ties tested | Add non-isotropic endpoint minimum and maximum ties, including gaps immediately inside and outside relative 1e-10. Compute discrete ties from the fitted model rather than noisy helper values. | Step 4 cases 16–17; repair |
| Error budgets conflict downstream | Evaluate phase classification, symmetry and canonical extrema at the returned fit; account for both outputs in paired identities and propagate strain errors through derived energy differences. Probe admissible coefficient and response errors. | Step 1 cases 10,16; Step 4 cases 8,10,14,18; general cases 5,6,8; grading_fix |
| Near-soft hard-direction cancellation | Use extended trigonometry and positive square-completed compliance work; independently solve normal eigenmodes with normalized algebraic eigenvectors. Add 90-digit direct-stress targets. | Step 3 cases 14–15; Step 4 case 18; repair |
| Visible text describes grading regimes | Replace test descriptions with supported physical regimes, public numerical acceptance conventions and response guarantees. | Visible YAML audit; clarification |
| Archive includes nested layers and editor caches | Package one task root and remove `.ipynb_checkpoints`; retain the exact supplied source text and append the inspected paper citation. | Archive inventory; repair |

Exact boundary isolation uses only the named public fitting dependency required
by Step 4. It leaves that function's least-squares accuracy contract unchanged
and does not require any source-fit algorithm to preserve an algebraic zero or
an exact symmetry through floating arithmetic. Ordinary, noisy, soft-shear,
near-degenerate, and asymmetric data are also fitted end to end.

Executed verification and remaining platform stages are listed in
`VALIDATION_REPORT.md`. The attached paper informs the constitutive design;
it supplies no copied numerical material targets.
