# Revision record

This revision addresses the findings in the supplied content-check notebook.
The existing task identity is retained, and the task still has four steps.

| Finding | Cause and repair | Regression / label |
|---|---|---|
| Step 1 is a short energy transcription | Replace scalar substitution with mixed prescribed/free elastic relaxation. Require positive curvature only in the free block and return equilibrium, stress, and energy. Update signature, dependencies and all interfaces. | Step 1 cases 8–20; difficulty_increase, repair |
| Conditioning endpoint 1000 absent | Derive an endpoint dataset from an independent analytic design-Gram eigensystem; explicitly include a 64-epsilon roundoff allowance in the public design thresholds. | Step 2 cases 22–23; grading_fix |
| Exact-zero integrated Born branches absent | Fit zero-shear and zero-determinant source datasets through the normal public API and classify their returned tensors. Do not inspect or replace the candidate function environment. | Step 4 cases 13–15, 18; robustness, grading_fix |
| Hidden positive determinant cutoff can pass | Include a positive normal determinant ratio near 1.49e-8, and compare directional responses at the returned tensor using independent stress/eigenmode work. | Step 3 cases 8,12,14,15; Step 4 cases 14,15,18; robustness |
| Only isotropic ties tested | Add non-isotropic endpoint minimum and maximum ties, including gaps immediately inside and outside relative 1e-10. Compute discrete ties from the fitted model rather than noisy helper values. | Step 4 cases 16–17; repair |
| Error budgets conflict downstream | Evaluate phase classification, symmetry and canonical extrema at the returned fit; account for both outputs in paired identities and propagate strain errors through derived energy differences. Probe admissible coefficient and response errors. | Step 1 cases 10,16; Step 4 cases 8,10,14,18; general cases 5,6,8; grading_fix |
| Near-soft hard-direction cancellation | Use extended trigonometry and positive square-completed compliance work; independently solve normal eigenmodes with normalized algebraic eigenvectors. Add 90-digit direct-stress targets. | Step 3 cases 14–15; Step 4 case 18; repair |
| Visible text describes grading regimes | Replace test descriptions with supported physical regimes, public numerical acceptance conventions and response guarantees. | Visible YAML audit; clarification |
| Archive includes nested layers and editor caches | Package one task root and remove `.ipynb_checkpoints`; retain the exact supplied source text and append the inspected paper citation. | Archive inventory; repair |

All graded cases call the public function normally. Exact source boundaries,
near-degenerate materials, and anisotropic ties are inferred end to end, with
classification and canonical directions defined at the actual returned fit.
There is no function introspection, environment mutation, dependency substitution,
or requirement that numerical fitting preserve an algebraic source symmetry.

Executed verification and remaining platform stages are listed in
`VALIDATION_REPORT.md`. The attached paper informs the constitutive design;
it supplies no copied numerical material targets.

## Oracle compatibility repair — 11 October 2026

The platform reported Step 4 failures in one-based tests 14,16,17,18
(zero-based cases13,15,16,17), with `AttributeError: __globals__`. The previous
cases assumed that an evaluated function exposed ordinary Python function
globals. Oracle uses a call-only proxy, so that assumption was invalid.

Rewrote those four cases to use only normal public calls. Zero-boundary,
near-degenerate, and anisotropic-tie expectations are derived from the actual
returned fit. No scientific implementations, function signatures, physical
contracts, other steps, or packaged mutants were changed.

Added call-only proxy verification of every case for both complete references
to the author validator. This regression reproduces the private-attribute
restriction responsible for the reported error. Repair label: grading_fix.

Local repaired-reference and proxy checks are recorded in the updated report.
A new platform Oracle run is still required; local proxy emulation is not a
claim that Harbor/Oracle itself has been executed.
