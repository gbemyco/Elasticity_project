# Revision record

Same scientific task and folder identity; no `problem_id` added. The supplied
archive already included many of the validation fixes requested by the first
content check. Those checks were retained and executed; this revision also
addresses the remaining scientific, provenance, and coverage issues together.

| Finding | Cause | Change / edit label | Regression evidence |
|---|---|---|---|
| Step 1 nonfinite input rejection uncovered | Missing invalid-input discriminator in the earlier submission | Retain NaN/inf strain and stiffness tests. **grading_fix** | step_1 case 4 |
| Step 1 stiffness shape uncovered | Malformed vectors/matrices not challenged | Retain short vector and 2D stiffness rejections. **grading_fix** | step_1 case 5 |
| Step 2 energies need exactly (M,) | Broadcasting could evade grading | Wrong observation count and 2D energies rejected. **grading_fix** | step_2 cases 7, 18; step_4 case 11 |
| Step 2 finiteness uncovered | Invalid observations could reach regression | NaN/inf energy, strains, and area rejected. **grading_fix** | step_2 cases 8, 9, 18 |
| Area positivity uncovered | Zero/negative normalization accepted by a wrong solution | Preserve positive-scalar rule and reject zero, negative, nonfinite, nonscalar area. **grading_fix** | step_2 cases 9, 18 |
| RMS cutoff could be wrong by an order of magnitude | Existing rejection far below the threshold | Accepted approximately 2e-6 and exact 1e-6; reject approximately 0.99e-6. **robustness** | step_2 cases 10, 12, 13 |
| Condition cutoff could wrongly be 100 | Only severe rejection originally tested | Accept moderate conditioning and approximately 999; reject approximately 1001. **robustness** | step_2 cases 11, 14, 15 |
| Step 3 stiffness validation uncovered | Correct tensor assumed by tests | Malformed and nonfinite stiffness explicitly rejected. **grading_fix** | step_3 case 5 |
| Step 3 nonempty finite 1D angles uncovered | Angle validation could be omitted | Empty, 2D, NaN and infinity directions rejected. **grading_fix** | step_3 case 6 |
| Born diagonal positivity not separated from determinant | Negative normal diagonals can have positive determinant | Negative normal diagonals, nonpositive shear, zero and negative determinant cases. **grading_fix** | step_3 cases 3, 7 |
| Step 4 angles not directly covered | Helper validation could hide skipped unstable-branch validation | Test invalid directions in stable AND unstable fits. **grading_fix** | step_4 case 3 |
| Step 4 stability classifications too narrow | Only negative determinant used before revision | Negative C66, both normal diagonals negative, and small negative shear curvature. **grading_fix** | step_4 cases 4, 12; general case 9 |
| Five Python float summaries untested | Numeric closeness accepts NumPy scalars | Exact public Python scalar types verified for stable and unstable results. **grading_fix** | step_4 cases 0, 4, 12 |
| Fitting and integrated tolerances inconsistent | Fit errors propagate to E and nu | Distinguish same-returned-tensor checks from underlying-tensor comparisons, with visible budgets. **clarification** | step_4 case 9; general case 7 |
| Near-soft determinant range poorly exercised | Comfortable positive determinant did not distinguish numerical cutoffs | Retain ratio approximately 1e-8 and add independent high-precision stress-solve targets. **robustness** | step_3 cases 8, 12 |
| Arbitrarily positive C66 could be mistaken for zero | All initial shear values comfortably positive | Direct and integrated oblique mechanics at C66=1e-6 N/m. **robustness** | step_3 case 9; step_4 case 10; general case 8 |
| Steps 1/2 overly prescriptive | Expanded energy/design supplied a transcription recipe | State constitutive model, physical regression objective and numerical contract; solver derives energy/design. **clarification** | Multiple work-conjugate and independent tensor-basis tests |
| Final step mainly helper assembly | Sampled extrema dictated without meaningful inference | Infer continuous global directional extrema, with oblique minimum and maximum outside the supplied samples. **difficulty_increase** | step_4 cases 5–9; general cases 3–7; sampled_extrema mutant |
| Noisy expected values reused the reference method | Repeating SVD OLS was weak independent evidence | QR targets; tensor stress solves; analytic rational extrema; independent second solution. **robustness** | step_2 cases 1, 16, 21; step_4 case 9 |
| Original sources claimed online checking not established by this revision | Historical checked-source claims could be mistaken for current evidence | Replace with actually retrieved numerical/constant sources and a self-contained continuum derivation. **clarification** | source.md and author validation report |

All four complete/per-step reference interfaces, all 67 parser cases, the
independent complete solution, 5 declared mutants, None/zero controls,
three clean-process configurations, and 80 additional author-side stress cases
were rerun. See `VALIDATION_REPORT.md` for actual outcomes and remaining external
checks. No closed/held task state, upload limit, or platform trial budget was
available in this workspace; submitting remains a user-side action.

## Packaging simplification

The submission includes one named scientific mutant for each of the four steps
and one complete whole-task mutant, matching the minimum in the supplied guide.
The additional mutation implementations were removed from the package. All 67
scientific and validation cases, both complete solutions, and the continuous
global-extrema contract are retained.
