"""Author-only scientific boundary probes; not files in the submitted task."""
from pathlib import Path
import json
import re

TASK=Path(__file__).parent/'tasks/2d_elasticity'
REFERENCE=(TASK/'solution.py').read_text()
SUITES={name:re.split(r'^# --- test case \d+ ---\s*$',
                     (TASK/'tests'/f'{name}.py').read_text(),flags=re.M)[1:]
        for name in ('step_2','step_4')}
PROBES={
    'step2_condition_ge1000': ('step_2',
        REFERENCE.replace('singular[0] / singular[-1] > 1000 * (1 + rounding)',
                          'singular[0] / singular[-1] >= 1000')),
    'step4_zero_shear_accepted': ('step_4',
        REFERENCE.replace('min(c11, c22, c66) > 0 and det > 0',
                          'c11 > 0 and c22 > 0 and c66 >= 0 and det > 0')),
    'step4_zero_determinant_accepted': ('step_4',
        REFERENCE.replace('min(c11, c22, c66) > 0 and det > 0',
                          'min(c11, c22, c66) > 0 and det >= 0')),
    'step4_relative_determinant_cutoff': ('step_4',
        REFERENCE.replace('min(c11, c22, c66) > 0 and det > 0',
                          'min(c11, c22, c66) > 0 and det > 1e-7*c11*c22')),
    'step4_larger_tied_angle': ('step_4',
        REFERENCE.replace('abs(ymin))[0]','abs(ymin))[-1]')
                 .replace('abs(ymax))[0]','abs(ymax))[-1]')),
    'step4_oversized_tie_tolerance': ('step_4',
        REFERENCE.replace('1e-10*abs(ymin)','1e-9*abs(ymin)')
                 .replace('1e-10*abs(ymax)','1e-9*abs(ymax)')),
}
results={}
for name,(suite,source) in PROBES.items():
    assert source!=REFERENCE,name
    rejected=[]
    for number,code in enumerate(SUITES[suite]):
        namespace={}
        exec(compile(source,name,'exec'),namespace)
        try:
            exec(compile(code,f'{suite}:{number}','exec'),namespace)
        except Exception:
            rejected.append(number)
    results[name]={'suite':suite,'rejected_by_cases':rejected}
assert all(r['rejected_by_cases'] for r in results.values())
print(json.dumps(results,indent=2))
(Path(__file__).parent/'boundary_results.json').write_text(json.dumps(results,indent=2)+'\n')
