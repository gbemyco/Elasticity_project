# Local validation report

This report describes author-side execution, not a platform quality decision.
Environment: Python 3.12.14; NumPy 2.3.5; PyYAML 6.0.3 (author validator only). Solutions import only NumPy.

## Executed checks

| Interface | Cases passed | Failed |
|---|---:|---:|
| solution.py | 67 | 0 |
| second_solution.py | 67 | 0 |
| per_step_1 | 8 | 0 |
| per_step_2 | 22 | 0 |
| per_step_3 | 14 | 0 |
| per_step_4 | 13 | 0 |

The two complete implementations each passed all 67 cases: step_1=8, step_2=22, step_3=14, step_4=13, general=10.
Per-step references were tested with only their declared earlier dependencies supplied.
Case numbering, declared counts and paths, signatures, contract fields, scaffold bodies,
dependency ordering, complete-solution imports, and final problem_io were checked.

## Mutation evidence

| Named mutant | Target | Rejecting case numbers |
|---|---|---|
| wrong_shear_factor | step_1 | 1, 3, 6, 7 |
| missing_unit_conversion | step_2 | 0, 1, 3, 6, 10, 11, 12, 14, 16, 17, 20, 21 |
| wrong_poisson_sign | step_3 | 0, 1, 2, 4, 8, 9, 11, 12 |
| sampled_extrema | step_4 | 5, 6, 7, 8, 9 |
| whole_task_wrong_shear | general | 0, 1, 2, 3, 4, 6, 7, 9 |

All five retained scientific mutants were rejected by their targeted suites.
The submission includes one mutant per evaluated step and one complete whole-task mutant.
All 67 test cases are retained; the removed mutation files are optional author controls.
The all-functions-return-None and all-functions-return-zero controls each failed all 67 cases.

## Clean-process repetition

| BLAS/OMP threads | Python hash seed | Reference | Alternative | Full validation seconds |
|---:|---:|---:|---:|---:|
| 1 | 0 | 67/67 | 67/67 | 0.6105 |
| 1 | 271 | 67/67 | 67/67 | 0.4732 |
| 2 | 913 | 67/67 | 67/67 | 0.5304 |

Each run used a new Python process and freshly loaded candidate namespaces for individual cases.
Tests use fixed inputs; the additional stress experiment uses seed 46371.

## Additional scientific stress verification

80 stable tensors spanning normal stiffness 40–900 N/m, coupling
of both signs (correlation magnitude <=0.85), and shear drawn logarithmically
between 1e-6 and approximately 500 N/m were tested. Each case compared
independent directional methods at the same tensor, inferred both tensors
from independent work-conjugate synthetic energies, checked responses and
attained extrema at each returned fit, and bounded extrema against 1,025
quadrant samples. The dense grid supplies bounds, not exact global targets.
Maximum same-tensor Young difference: 1.705e-13 N/m.
Maximum stiffness difference between the SVD and QR fits: 2.160e-12 N/m.
Additional stress-check runtime: 0.1622 seconds.

## Fairness and numerical scope

Pairwise symmetry/scaling comparisons combine the error budgets of both
computed quantities. Integrated comparisons at a returned fit are separated
from comparisons to a noise-free underlying tensor. Fitted instability tests
use sign margins larger than the allowed stiffness error; exactly zero shear
is checked directly in step 3, where no regression uncertainty intervenes.
The near-soft stress target was independently computed at 90 digits during
authoring; mpmath is not imported by the submitted solutions or tests.

## Reproduction and outstanding external checks

With NumPy and PyYAML available, run from this archive root:

```sh
python3 validate.py
python3 validate_stress.py
```

The second command also repeats validation in three clean-process configurations.
Neither validator is part of solution execution or the evaluator test bundle.

No platform upload, live upload-parser check, exploit probe, difficulty probe,
benchmark rollout, trajectory analysis, or human review was executed here.
The current upload-panel schema and limits were not available. The original
schema and stable task identity are preserved; confirm the upload preview.
Author identity and affiliation metadata were preserved from the supplied
archive and should be confirmed by its owner before submission.
No paper retrieval or literature-target verification is claimed beyond the
actually retrieved numerical and constant sources listed in source.md.
These results support numerical correctness and regression coverage; they
cannot guarantee a benchmark difficulty band or final platform acceptance.
