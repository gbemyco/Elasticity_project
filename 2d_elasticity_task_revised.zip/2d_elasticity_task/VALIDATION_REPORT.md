# Executed author verification

Date: 10 October 2026. Python 3.12.14; NumPy 2.3.5.
This records actual local execution, not a platform quality decision.

| Evaluated suite | Cases | Reference | Independent solution |
|---|---:|---:|---:|
| Step 1: constrained equilibrium | 21 | 21 | 21 |
| Step 2: physical least squares | 24 | 24 | 24 |
| Step 3: directional mechanics | 16 | 16 | 16 |
| Step 4: integrated mechanics | 19 | 19 | 19 |
| Whole task | 10 | 10 | 10 |
| Total | 90 | 90 | 90 |

Each per-step reference also passes its suite with only the explicitly declared
earlier-step dependencies supplied. Scaffolds, reference signatures, final
problem I/O, paths, consecutive test markers, case counts, contracts, and imports
passed the author schema audit. All solution and graded-test imports are NumPy.
Visible scientific descriptions contain no test-case disclosures.

The reference and independent implementation share the physical model, but use
different numerical constructions: block elimination versus scalar square
completion for relaxation; constitutive basis-response SVD versus explicit-design
QR fitting; positive Schur work versus normal-eigenmode stress work for response;
quadratic stationary geometry versus derivative-root search for global extrema.
Analytic isotropic, auxetic, uniaxial relaxation, rational oblique extrema, and
analytic design-Gram eigenvalues provide independent evidence.

Five packaged scientific mutants are rejected by their targeted suites:
wrong shear factor (Step 1), missing unit conversion (Step 2), wrong Poisson sign
(Step 3), sampled global extrema (Step 4), and whole-task wrong shear. Detailed
rejecting cases are recorded in `validation_results.json`. Separate author-only
inline probes reject cond>=1000, acceptance of zero shear or zero determinant,
a relative positive determinant cutoff, larger-angle tie selection, and an
oversized tie tolerance. No extra mutant files are added to the task.

Both all-function-return-None and all-function-return-zero controls are rejected
by all 90 cases. Admissible intermediate-error checks pass 1,250 case evaluations
per complete implementation, including 42 combinations of coefficient-budget
perturbations and sampled-response perturbations. Twelve Step 1 output-error
variants pass all 21 cases (252 evaluations), including smooth input-dependent
errors and independent strain, stress, and energy budgets.

Three clean-process repetitions pass reference, alternative, all per-step
references, five mutants, and both no-op controls with thread/hash configurations
(1,0), (1,271), and (2,913). Eighty deterministic material/design pairs (seed46371)
pass additional independent response and continuous-extrema checks. Maximum
SVD/QR stiffness difference is 2.16005e-12 N/m.

An author-only 90-digit direct stress-solve and strain-tensor projection oracle
passes 2,268 directions across nine materials, including very asymmetric normal
stiffness, positive and negative coupling, weak shear, and offsets around stiff
loading directions near a soft eigenmode. Every discrepancy is inside the
published absolute-plus-relative output budget. Worst Poisson error uses
1.519% of its tolerance budget.
`near_soft_results.json` records the actual material and precision evidence.
The oracle package is unnecessary for solving or grading this NumPy-only task.

Strict phase classification and canonical ties are defined at the returned
fitted tensor. Exact-zero boundary isolation supplies the named public fitting
dependency with an admissible exact fitted vector; real fitting is additionally
checked end to end. No numerical snapping, stability cutoff, or demand that a
source symmetry survive a permitted coefficient error is imposed.

The user's original source text is preserved verbatim as the prefix of
`source.md`, followed by the supplied Herrero–Ramírez paper citation and explicit
construction limits. That new article was inspected directly. Earlier checked
source claims and author identity metadata are user-supplied, not independently
reverified in this revision.

The actual platform upload preview/parser, content checker, exploit and difficulty
probes, model rollouts, human review, and final acceptance were not executed here.
No mapping-file schema was supplied; the stable `tasks/2d_elasticity` folder is
preserved, without inventing `_id_mapping.json` or a placeholder identity.
