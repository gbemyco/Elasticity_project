"""Author-only check that admissible intermediate errors remain admissible.

This script is independent of the task runtime. It substitutes public helpers
with results inside their published error budgets, then runs the scientific
tests. The original helper still validates every input before any perturbation.
"""

import argparse
import itertools
import json
from pathlib import Path
import re

import numpy as np


def test_cases(task_directory, suite):
    text = (task_directory / "tests" / f"{suite}.py").read_text()
    pieces = re.split(r"# --- test case (\d+) ---", text)
    return [(int(pieces[index]), pieces[index + 1])
            for index in range(1, len(pieces), 2)]


def implementation_namespace(task_directory, implementation, fit_error=None,
                             direction_error=False):
    namespace = {}
    path = task_directory / implementation
    exec(compile(path.read_text(), str(path), "exec"), namespace)

    if fit_error is not None:
        original_fit = namespace["fit_stiffness_2d"]

        def perturbed_fit(*arguments):
            fitted = original_fit(*arguments)
            # Exact-model accuracy is the stricter of the two fitting budgets.
            if callable(fit_error):
                error = fit_error(fitted)
            else:
                error = np.asarray(fit_error, dtype=float)
            budget = 1e-5 + 1e-8 * np.abs(fitted)
            assert np.all(np.abs(error) <= budget)
            return fitted + error

        namespace["fit_stiffness_2d"] = perturbed_fit

    if direction_error:
        original_direction = namespace["directional_moduli_2d"]

        def perturbed_direction(stiffness_npm, angles_rad):
            young, poisson = original_direction(stiffness_npm, angles_rad)
            # A smooth deterministic error remains inside both direct-response
            # contracts, while differing between principal-axis directions.
            signed = 0.8 * np.cos(2 * np.asarray(angles_rad, dtype=float))
            young_error = signed * (1e-8 + 1e-9 * np.abs(young))
            poisson_error = signed * (1e-10 + 1e-9 * np.abs(poisson))
            return young + young_error, poisson + poisson_error

        namespace["directional_moduli_2d"] = perturbed_direction
    return namespace


def run_suite(task_directory, implementation, suite, fit_error=None,
              direction_error=False):
    passed, failed = [], []
    for case_number, code in test_cases(task_directory, suite):
        # Every case gets fresh function globals. A test may temporarily bind
        # a public dependency to exercise an exact physical boundary.
        namespace = implementation_namespace(task_directory, implementation,
                                             fit_error, direction_error)
        try:
            exec(compile(code, f"{suite}:case{case_number}", "exec"),
                 dict(namespace))
        except Exception as error:
            failed.append({"case": case_number,
                           "error": type(error).__name__,
                           "message": str(error)})
        else:
            passed.append(case_number)
    return {"passed": len(passed), "total": len(passed) + len(failed),
            "failures": failed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_directory", nargs="?", type=Path,
                        default=Path(__file__).parent / "tasks" / "2d_elasticity")
    parser.add_argument("--report", type=Path)
    arguments = parser.parse_args()

    fits = [("unperturbed", None)]
    for name, index, error in [("C11_plus_5e-6", 0, 5e-6),
                               ("C12_plus_5e-6", 2, 5e-6),
                               ("C66_plus_5e-6", 3, 5e-6),
                               ("C66_minus_5e-6", 3, -5e-6)]:
        vector = np.zeros(4)
        vector[index] = error
        fits.append((name, vector))

    # Check the corners of the componentwise fitting budget, not only isolated
    # component changes. This probes propagation through unique oblique angles.
    for signs in itertools.product((-1., 1.), repeat=4):
        signs_array = np.array(signs)

        def corner_error(fitted, signs_array=signs_array):
            return 0.8 * signs_array * (1e-5 + 1e-8 * np.abs(fitted))

        label = "budget_corner_" + "".join("p" if sign > 0 else "m"
                                          for sign in signs)
        fits.append((label, corner_error))

    report = {"purpose": "accept conforming intermediate numerical errors",
              "implementations": {}}
    for implementation in ("solution.py", "second_solution.py"):
        outcomes = {}
        for direction_error in (False, True):
            label = "direction_error" if direction_error else "unperturbed"
            outcomes[f"step_3:{label}"] = run_suite(
                arguments.task_directory, implementation, "step_3",
                direction_error=direction_error)
        for label, fit_error in fits:
            for direction_error in (False, True):
                probe = label + ("+direction_error" if direction_error else "")
                for suite in ("step_4", "general"):
                    outcomes[f"{suite}:{probe}"] = run_suite(
                        arguments.task_directory, implementation, suite,
                        fit_error, direction_error)
        report["implementations"][implementation] = outcomes

    report["all_passed"] = all(
        not outcome["failures"]
        for outcomes in report["implementations"].values()
        for outcome in outcomes.values())
    serialized = json.dumps(report, indent=2)
    if arguments.report:
        arguments.report.write_text(serialized + "\n")
    print(serialized)
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
