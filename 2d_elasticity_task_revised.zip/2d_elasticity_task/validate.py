"""Author-side validator; not part of solution execution."""
from pathlib import Path
import ast
import contextlib
import io
import json
import re
import sys
import time
import traceback
import yaml

FUNCTIONS = ['elastic_energy_density_2d', 'fit_stiffness_2d',
             'directional_moduli_2d', 'analyze_elastic_2d']

def load(path, namespace=None):
    ns = {} if namespace is None else namespace
    exec(compile(path.read_text(), str(path), 'exec'), ns)
    return ns

def cases(path):
    text = path.read_text()
    markers = list(re.finditer(r'^# --- test case (\d+) ---\s*$', text, re.M))
    if not markers or [int(m.group(1)) for m in markers] != list(range(len(markers))):
        raise AssertionError(f'Invalid case numbering: {path}')
    if text[:markers[0].start()].strip():
        raise AssertionError(f'Unexpected pre-case setup: {path}')
    return [(i, text[m.end():markers[i+1].start() if i+1 < len(markers) else len(text)])
            for i,m in enumerate(markers)]

def run_case(base, code, label):
    # Every case receives a fresh candidate namespace and self-contained setup.
    ns = base()
    try:
        exec(compile(code, label, 'exec'), ns)
        return None
    except Exception as error:
        return {'error': type(error).__name__, 'message': str(error),
                'traceback': traceback.format_exc(limit=3)}

def validate(root):
    start = time.perf_counter()
    task = root/'tasks/2d_elasticity'
    p = yaml.safe_load((task/'problem.yaml').read_text())
    assert p['domain'] == 'physics' and 'problem_id' not in p
    assert len(p['sub_steps']) == 4
    paths = [p['general_tests'], p['second_solution'], 'solution.py', 'background.md', 'source.md']
    headers = {}
    for i,step in enumerate(p['sub_steps'], 1):
        assert step['step_number'] == i
        assert set(step['contract']) == {'quantity','assumptions','result_kind','valid_input_ranges','units','output_shape','step_dependencies'}
        assert all(x < i for x in step['contract']['step_dependencies'])
        assert step['n_test_cases'] == len(cases(task/step['tests']))
        for field in ['scaffold','solution','tests']:
            paths.append(step[field])
        for mutant in step['mutants']:
            paths.append(mutant['file'])
        scaffold = ast.parse((task/step['scaffold']).read_text())
        funcs = [x for x in scaffold.body if isinstance(x,ast.FunctionDef)]
        assert len(funcs)==1 and funcs[0].name==FUNCTIONS[i-1]
        headers[FUNCTIONS[i-1]] = ast.dump(funcs[0].args)
        prompt_header = ast.parse(step['function_header']).body[0]
        assert ast.dump(prompt_header.args) == headers[FUNCTIONS[i-1]]
        ref_funcs = [x for x in ast.parse((task/step['solution']).read_text()).body if isinstance(x,ast.FunctionDef)]
        assert len(ref_funcs)==1 and ref_funcs[0].name==FUNCTIONS[i-1]
        assert ast.dump(ref_funcs[0].args)==headers[FUNCTIONS[i-1]]
    for mutant in p['mutants']:
        paths.append(mutant['file'])
    for path in paths:
        target = (task/path).resolve()
        assert target.is_relative_to(task.resolve()) and target.is_file(), path
    for source in ['solution.py','second_solution.py']:
        tree = ast.parse((task/source).read_text())
        for node in tree.body:
            if isinstance(node,ast.FunctionDef) and node.name in headers:
                assert ast.dump(node.args)==headers[node.name]
        imports = [node for node in ast.walk(tree) if isinstance(node,(ast.Import,ast.ImportFrom))]
        assert all(isinstance(x,ast.Import) and all(a.name=='numpy' for a in x.names) for x in imports)
    assert ast.dump(ast.parse(p['problem_io']).body[0].args)==headers[FUNCTIONS[-1]]

    suites = {f'step_{i}': cases(task/f'tests/step_{i}.py') for i in range(1,5)}
    suites['general'] = cases(task/'tests/general.py')
    results = {'schema':'passed','case_counts':{k:len(v) for k,v in suites.items()},'correct':{},'mutants':{},'controls':{}}
    for name in ['solution.py','second_solution.py']:
        passed=0; errors=[]
        for suite,tests in suites.items():
            for number,code in tests:
                error = run_case(lambda:load(task/name),code,f'{suite}:{number}')
                if error: errors.append({'suite':suite,'case':number,**error})
                else: passed+=1
        results['correct'][name]={'passed':passed,'failed':errors}
    for i in range(1,5):
        def step_base(i=i):
            ns={}
            # Evaluation supplies only declared earlier functions.
            for dep in p['sub_steps'][i-1]['contract']['step_dependencies']:
                load(task/p['sub_steps'][dep-1]['solution'],ns)
            return load(task/p['sub_steps'][i-1]['solution'],ns)
        errors=[]
        for number,code in suites[f'step_{i}']:
            error=run_case(step_base,code,f'per_step_{i}:{number}')
            if error: errors.append({'case':number,**error})
        results['correct'][f'per_step_{i}']={'passed':len(suites[f'step_{i}'])-len(errors),'failed':errors}
        for mutant in p['sub_steps'][i-1]['mutants']:
            def mutant_base(mutant=mutant):
                return load(task/mutant['file'], load(task/'solution.py'))
            rejected=[]
            for number,code in suites[f'step_{i}']:
                if run_case(mutant_base,code,f'mutant_{i}:{number}'):
                    rejected.append(number)
            results['mutants'][mutant['name']]={'target':f'step_{i}','rejected_by_cases':rejected}
    for mutant in p['mutants']:
        rejected=[i for i,code in suites['general'] if run_case(lambda:load(task/mutant['file']),code,f'whole_mutant:{i}')]
        results['mutants'][mutant['name']]={'target':'general','rejected_by_cases':rejected}
    for control,value in [('none','None'),('zero','0.0')]:
        rejected={}
        def control_base():
            ns={}
            for f in FUNCTIONS:
                exec(f'def {f}(*args, **kwargs): return {value}',ns)
            return ns
        for suite,tests in suites.items():
            rejected[suite]=[i for i,code in tests if run_case(control_base,code,f'control:{suite}:{i}')]
        results['controls'][control]=rejected
    results['seconds']=round(time.perf_counter()-start,4)
    results['success']=not any(v['failed'] for v in results['correct'].values()) and all(v['rejected_by_cases'] for v in results['mutants'].values()) and all(len(d[k])==len(v) for d in results['controls'].values() for k,v in suites.items())
    return results

if __name__=='__main__':
    root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
    result=validate(root)
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result['success'] else 1)
