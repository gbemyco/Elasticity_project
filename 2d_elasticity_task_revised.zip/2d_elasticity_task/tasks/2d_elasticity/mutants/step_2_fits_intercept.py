# Deliberate author-side mutant: Fits an unphysical baseline even though energies are relative to zero strain.
import numpy as np

def fit_stiffness_2d(strains, delta_energy_ev, area_ang2):
    """Ordinary least squares in the physical, unscaled quadratic design."""
    e = np.asarray(strains, dtype=float)
    y = np.asarray(delta_energy_ev, dtype=float)
    a = np.asarray(area_ang2, dtype=float)
    if e.ndim != 2 or e.shape[1] != 3 or not np.all(np.isfinite(e)) or np.any(np.abs(e) > 0.03):
        raise ValueError("Invalid strains")
    if y.shape != (len(e),) or not np.all(np.isfinite(y)):
        raise ValueError("Invalid energies")
    if a.ndim != 0 or not np.isfinite(a) or a <= 0:
        raise ValueError("Invalid area")
    if len(e) < 4:
        raise ValueError("At least four observations are needed")
    x, z, g = e.T
    design = np.column_stack((x*x/2, z*z/2, x*z, g*g/2))
    if np.any(np.sqrt(np.mean(design*design, axis=0)) < 1e-6):
        raise ValueError("Insufficient quadratic strain signal")
    singular = np.linalg.svd(design, compute_uv=False)
    if singular[-1] <= 0 or singular[0] / singular[-1] > 1000:
        raise ValueError("Unidentifiable or ill-conditioned design")
    return np.linalg.lstsq(np.column_stack((design, np.ones(len(e)))), y * (16.02176634 / float(a)), rcond=None)[0][:4]
