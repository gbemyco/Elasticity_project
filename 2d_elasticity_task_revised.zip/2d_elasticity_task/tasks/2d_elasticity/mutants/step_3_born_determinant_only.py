# Deliberate author-side mutant: Checks determinant but omits independent diagonal positivity.
import numpy as np

def directional_moduli_2d(stiffness_npm, angles_rad):
    """Engineering compliance projected onto longitudinal and transverse axes."""
    c = np.asarray(stiffness_npm, dtype=float)
    theta = np.asarray(angles_rad, dtype=float)
    if c.shape != (4,) or not np.all(np.isfinite(c)):
        raise ValueError("Invalid stiffness")
    if theta.ndim != 1 or theta.size == 0 or not np.all(np.isfinite(theta)):
        raise ValueError("Invalid angles")
    # Extended arithmetic protects the subtraction in the normal-block determinant.
    c11, c22, c12, c66 = c.astype(np.longdouble)
    det = c11*c22 - c12*c12
    if det <= 0:
        raise ValueError("Born-unstable stiffness")
    s11, s22, s12, s66 = c22/det, c11/det, -c12/det, 1/c66
    u = np.cos(theta).astype(np.longdouble)**2
    v = np.sin(theta).astype(np.longdouble)**2
    axial = s11*u*u + s22*v*v + (2*s12+s66)*u*v
    transverse = s12*(u*u+v*v) + (s11+s22-s66)*u*v
    return np.asarray(1/axial, dtype=float), np.asarray(-transverse/axial, dtype=float)
