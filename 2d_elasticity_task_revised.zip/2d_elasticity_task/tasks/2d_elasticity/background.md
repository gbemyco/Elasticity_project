
## Scientific Background

This task examines the in-plane mechanical properties of two-dimensional (2D) materials using harmonic elasticity theory and DFT energy–strain data.

In DFT, 2D materials are modelled using supercells containing vacuum. To avoid dependence on vacuum thickness, elastic stiffness is expressed in N/m rather than the conventional 3D unit of Pa.

For an orthotropic 2D material, the engineering strain and stress vectors are:

    e = [exx, eyy, gxy], where gxy = 2*exy
    s = [sxx, syy, txy]

The elastic stiffness matrix is:

    C = [[C11, C12,   0],
         [C12, C22,   0],
         [  0,   0, C66]]

The harmonic elastic energy density is:

    U = 0.5 * eᵀ C e

DFT energy differences, normalized by the unstrained in-plane area, allow the four independent elastic constants to be determined using uniaxial, biaxial, and shear strains.

The compliance matrix, S = C⁻¹, describes the directional mechanical response. Young's modulus and Poisson's ratio are obtained by projecting the strain tensor along the loading and transverse directions, using the correct engineering-shear convention.

The final analysis reports continuous directional Young-modulus extrema over
all orientations, while its directional arrays are evaluated at the requested
angle samples. A sparse angle grid can miss an oblique soft or stiff direction.
The visible step prompt defines the canonical quadrant and numerical tie rule.


