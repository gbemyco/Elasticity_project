# Grounding, sources actually checked, and target provenance

## Checked sources

1. NumPy 2.3.5 official linear-algebra implementation and API documentation,
   `numpy/linalg/_linalg.py`:
   https://github.com/numpy/numpy/blob/v2.3.5/numpy/linalg/_linalg.py
   Retrieved through the official raw-source URL during revision. The `lstsq`
   documentation defines the Euclidean-residual minimizer, and `cond` documents
   the default spectral condition number computed with SVD. The reference uses
   SVD-based least squares; the independent implementation uses reduced QR.

2. SciPy 1.16.0 official CODATA constants table,
   `scipy/constants/_codata.py`:
   https://github.com/scipy/scipy/blob/v1.16.0/scipy/constants/_codata.py
   Retrieved and checked during revision. The current electron-volt/joule
   relationship is exactly 1.602176634e-19 J. Since one Angstrom² is 1e-20 m²,
   one eV/Angstrom² is 16.02176634 J/m² = 16.02176634 N/m.
   SciPy is a checked constant source, **not** a solution dependency.

The original archive listed journal articles as online-checked sources. Those
articles could not be retrieved through the available egress policy in this
revision; no new online verification of them is claimed. They are not needed
for any test target or for the self-contained constitutive derivation below.
No test uses a copied literature elasticity target or a material-specific claim.

## Continuum derivation checked in this revision

The model is explicitly assumed, rather than inferred from a particular paper.
For engineering strain e=[exx,eyy,gxy], gxy=2*epsilon_xy, the work-conjugate stress
is [sigma_xx,sigma_yy,tau_xy]. Orthotropy in the material axes sets C16=C26=0.
Stress is C e. Integrating work along lambda e from the unstressed origin gives
U = integral_0^1 (lambda C e).e d lambda = (e.C.e)/2.
This derives the shear normalization and mixed C12 term. Multiplying by the
fixed unstrained area converts areal energy to a total-energy difference.

The quadratic form separates into a normal 2x2 block and the independent shear
block. Positive definiteness therefore requires C11,C22,C66>0 and
D=C11*C22-C12²>0. Positive D alone cannot exclude both negative normal diagonals.

For a unit uniaxial stress, sigma=n outer n. Solve its engineering stress vector
through C. Convert gamma_xy back to tensor epsilon_xy=gamma_xy/2 before taking
the longitudinal and transverse tensor projections. This directly yields
E=1/epsilon_nn and nu=-epsilon_mm/epsilon_nn; it also establishes the usual
orthotropic principal-axis and reciprocal Poisson identities.

For auditing the continuous extrema independently, writing t=cos(theta)² gives
the longitudinal compliance

    q(t) = S11*t² + S22*(1-t)² + (2*S12+S66)*t*(1-t),  0<=t<=1.

It is positive for a stable tensor. Endpoints and an interior stationary point
are sufficient to obtain its global extrema, and E=1/q reverses their ordering.
The reference uses this reduction. The second implementation instead solves
the original stress tensor and locates a root of the projected compliance's
angle derivative by bisection. It does not copy this polynomial optimizer.

## Independent targets and special cases

- Isotropic plane-stress stiffness is obtained independently from E and nu:
  C11=C22=E/(1-nu²), C12=nu*E/(1-nu²), C66=E/[2(1+nu)]. It predicts constant E
  and nu for every direction, including the auxetic isotropic case.
- Principal directions give Ex=D/C22, Ey=D/C11, nu_xy=C12/C22,
  nu_yx=C12/C11, establishing unit, sign, and reciprocity checks.
- At C=[200,80,20,10] N/m, exact rational algebra gives the interior
  compliance maximum at cos(theta)²=14/31, with Emin=310/9 N/m.
  It is a Young-modulus minimum missed by two principal-axis samples.
- At C=[100,70,15,200] N/m, exact rational algebra gives the interior compliance
  minimum at cos(theta)²=523/886, with Emax=354400/2203 N/m.
  It is an oblique global Young-modulus maximum missed by principal samples.
- Noisy stiffness targets are computed by independent QR projection, not by
  copying the reference's SVD/lstsq outputs. Duplicate observations and a noisy
  energy offset distinguish the specified OLS/no-intercept model.
- The near-soft target in step_3 case 12 was calculated during authoring with
  a 90-decimal-digit direct stress solve at the exact represented float inputs.
  Its inline values are checked by both complete implementations.
  Arbitrary precision is not needed at evaluation time.

All data fixtures are original synthetic instances of the stated model. The
independent implementation, analytic identities, symmetry/scaling relations,
and rational extrema supply complementary checks. None alone substitutes for
the others. Detailed actual runs and their limits are recorded in the root
`VALIDATION_REPORT.md`; passing a platform or human review is not claimed.
