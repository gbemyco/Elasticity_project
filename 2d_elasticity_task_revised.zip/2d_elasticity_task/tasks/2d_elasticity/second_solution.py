import numpy as np


def elastic_energy_density_2d(strains, stiffness_npm):
    e = np.asarray(strains, dtype=float)
    c = np.asarray(stiffness_npm, dtype=float)
    if e.ndim != 2 or e.shape[1] != 3 or not np.all(np.isfinite(e)) or np.any(abs(e) > 0.03):
        raise ValueError('Invalid strain array')
    if c.shape != (4,) or not np.all(np.isfinite(c)):
        raise ValueError('Invalid stiffness')
    matrix = np.array([[c[0], c[2], 0.], [c[2], c[1], 0.], [0., 0., c[3]]])
    # Work-conjugate stress, followed by trapezoidal work from zero strain.
    stress = e @ matrix.T
    return np.sum(e * stress, axis=1) / (2 * 16.02176634)


def fit_stiffness_2d(strains, delta_energy_ev, area_ang2):
    e = np.asarray(strains, dtype=float)
    energy = np.asarray(delta_energy_ev, dtype=float)
    area = np.asarray(area_ang2, dtype=float)
    if e.ndim != 2 or e.shape[1] != 3 or not np.all(np.isfinite(e)) or np.any(abs(e) > .03):
        raise ValueError('Invalid strains')
    if energy.shape != (len(e),) or not np.all(np.isfinite(energy)):
        raise ValueError('Invalid energies')
    if area.ndim != 0 or not np.isfinite(area) or area <= 0 or len(e) < 4:
        raise ValueError('Invalid area or number of observations')
    # Construct columns as responses of the four constitutive basis matrices.
    basis = np.zeros((4, 3, 3))
    basis[0, 0, 0] = basis[1, 1, 1] = basis[3, 2, 2] = 1.
    basis[2, 0, 1] = basis[2, 1, 0] = 1.
    design = .5 * np.einsum('ni,kij,nj->nk', e, basis, e)
    if np.any(np.linalg.norm(design, axis=0) / np.sqrt(len(e)) < 1e-6):
        raise ValueError('Insufficient signal')
    singular = np.linalg.svd(design, compute_uv=False)
    if singular[-1] <= 0 or singular[0] / singular[-1] > 1000:
        raise ValueError('Unidentifiable design')
    q, r = np.linalg.qr(design, mode='reduced')
    return np.linalg.solve(r, q.T @ (energy * (16.02176634 / float(area))))


def directional_moduli_2d(stiffness_npm, angles_rad):
    c = np.asarray(stiffness_npm, dtype=float)
    angles = np.asarray(angles_rad, dtype=float)
    if c.shape != (4,) or not np.all(np.isfinite(c)):
        raise ValueError('Invalid stiffness')
    if angles.ndim != 1 or angles.size == 0 or not np.all(np.isfinite(angles)):
        raise ValueError('Invalid directions')
    ld = c.astype(np.longdouble)
    if min(ld[0], ld[1], ld[3]) <= 0 or ld[0]*ld[1]-ld[2]*ld[2] <= 0:
        raise ValueError('Unstable material')
    matrix = np.array([[c[0], c[2], 0.], [c[2], c[1], 0.], [0., 0., c[3]]])
    co, si = np.cos(angles), np.sin(angles)
    applied = np.column_stack((co*co, si*si, co*si))
    strain_vector = np.linalg.solve(matrix, applied.T).T
    strain_tensor = np.empty((len(angles), 2, 2))
    strain_tensor[:, 0, 0] = strain_vector[:, 0]
    strain_tensor[:, 1, 1] = strain_vector[:, 1]
    strain_tensor[:, 0, 1] = strain_tensor[:, 1, 0] = strain_vector[:, 2]/2
    n = np.column_stack((co, si))
    m = np.column_stack((-si, co))
    axial = np.einsum('ni,nij,nj->n', n, strain_tensor, n)
    transverse = np.einsum('ni,nij,nj->n', m, strain_tensor, m)
    return 1/axial, -transverse/axial


def analyze_elastic_2d(strains, delta_energy_ev, area_ang2, angles_rad):
    angles = np.asarray(angles_rad, dtype=float)
    if angles.ndim != 1 or angles.size == 0 or not np.all(np.isfinite(angles)):
        raise ValueError('Invalid angular sampling')
    c = fit_stiffness_2d(strains, delta_energy_ev, area_ang2)
    ld = c.astype(np.longdouble)
    stable = bool(min(ld[0], ld[1], ld[3]) > 0 and ld[0]*ld[1]-ld[2]*ld[2] > 0)
    if not stable:
        young = np.full(angles.shape, np.nan)
        poisson = young.copy()
        emin = emax = ratio = amin = amax = float('nan')
    else:
        young, poisson = directional_moduli_2d(c, angles)
        matrix = np.array([[c[0],c[2],0.], [c[2],c[1],0.], [0.,0.,c[3]]])

        def reduced_slope(theta):
            co, si = np.cos(theta), np.sin(theta)
            e = np.linalg.solve(matrix, [co*co, si*si, co*si])
            # Derivative of longitudinal strain, with the endpoint sin(2theta) removed.
            return 2*(e[1]-e[0]) + (co*co-si*si)/c[3]

        candidates = [0., float(np.pi/2)]
        left, right = 0., float(np.pi/2)
        fl, fr = reduced_slope(left), reduced_slope(right)
        if fl*fr < 0:
            for _ in range(64):
                middle = (left+right)/2
                fm = reduced_slope(middle)
                if fm == 0:
                    left = right = middle
                    break
                if (fl < 0) == (fm < 0):
                    left, fl = middle, fm
                else:
                    right = middle
            candidates.append((left+right)/2)
        candidates = np.sort(candidates)
        values, _ = directional_moduli_2d(c, candidates)
        emin, emax = float(min(values)), float(max(values))
        amin = float(candidates[np.flatnonzero(abs(values-emin) <= 1e-10*abs(emin))[0]])
        amax = float(candidates[np.flatnonzero(abs(values-emax) <= 1e-10*abs(emax))[0]])
        ratio = float(emax/emin)
    return {'stiffness_npm': c, 'born_stable': stable,
            'young_npm': young, 'poisson': poisson,
            'young_min_npm': emin, 'young_max_npm': emax,
            'anisotropy_ratio': ratio,
            'theta_young_min_rad': amin, 'theta_young_max_rad': amax}
