import numpy as np

def elastic_energy_density_2d(strains, stiffness_npm):
    """Areal harmonic energy; negative curvature is permitted in this diagnostic."""
    e = np.asarray(strains, dtype=float)
    c = np.asarray(stiffness_npm, dtype=float)
    if e.ndim != 2 or e.shape[1] != 3 or not np.all(np.isfinite(e)) or np.any(np.abs(e) > 0.03):
        raise ValueError("Invalid strains")
    if c.shape != (4,) or not np.all(np.isfinite(c)):
        raise ValueError("Invalid stiffness")
    x, y, g = e.T
    return (c[0]*x*x/2 + c[1]*y*y/2 + c[2]*x*y + c[3]*g*g/2) / 16.02176634


import numpy as np

def fit_stiffness_2d(strains, delta_energy_ev, area_ang2):
    """Ordinary least squares in the physical, unscaled quadratic design."""
    e = np.asarray(strains, dtype=float)
    y = np.asarray(delta_energy_ev, dtype=float)
    a = np.asarray(area_ang2, dtype=float)
    if e.ndim != 2 or e.shape[1] != 3 or not np.all(np.isfinite(e)) or np.any(np.abs(e) > 0.03):
        raise ValueError("Invalid strains")
    if y.shape != (len(e),) or not np.all(np.isfinite(y)):
        raise ValueError("Invalid energies")
    if a.ndim != 0 or not np.isfinite(a) or a <= 0:
        raise ValueError("Invalid area")
    if len(e) < 4:
        raise ValueError("At least four observations are needed")
    x, z, g = e.T
    design = np.column_stack((x*x/2, z*z/2, x*z, g*g/2))
    if np.any(np.sqrt(np.mean(design*design, axis=0)) < 1e-6):
        raise ValueError("Insufficient quadratic strain signal")
    singular = np.linalg.svd(design, compute_uv=False)
    if singular[-1] <= 0 or singular[0] / singular[-1] > 1000:
        raise ValueError("Unidentifiable or ill-conditioned design")
    return np.linalg.lstsq(design, y * (16.02176634 / float(a)), rcond=None)[0]


import numpy as np

def directional_moduli_2d(stiffness_npm, angles_rad):
    """Engineering compliance projected onto longitudinal and transverse axes."""
    c = np.asarray(stiffness_npm, dtype=float)
    theta = np.asarray(angles_rad, dtype=float)
    if c.shape != (4,) or not np.all(np.isfinite(c)):
        raise ValueError("Invalid stiffness")
    if theta.ndim != 1 or theta.size == 0 or not np.all(np.isfinite(theta)):
        raise ValueError("Invalid angles")
    # Extended arithmetic protects the subtraction in the normal-block determinant.
    c11, c22, c12, c66 = c.astype(np.longdouble)
    det = c11*c22 - c12*c12
    if min(c11, c22, c66) <= 0 or det <= 0:
        raise ValueError("Born-unstable stiffness")
    s11, s22, s12, s66 = c22/det, c11/det, -c12/det, 1/c66
    u = np.cos(theta).astype(np.longdouble)**2
    v = np.sin(theta).astype(np.longdouble)**2
    axial = s11*u*u + s22*v*v + (2*s12+s66)*u*v
    transverse = s12*(u*u+v*v) + (s11+s22-s66)*u*v
    return np.asarray(1/axial, dtype=float), np.asarray(-transverse/axial, dtype=float)


import numpy as np

def analyze_elastic_2d(strains, delta_energy_ev, area_ang2, angles_rad):
    """Infer stiffness and find global elastic extrema over all loading directions."""
    theta = np.asarray(angles_rad, dtype=float)
    if theta.ndim != 1 or theta.size == 0 or not np.all(np.isfinite(theta)):
        raise ValueError("Invalid angles")
    c = fit_stiffness_2d(strains, delta_energy_ev, area_ang2)
    c11, c22, c12, c66 = c.astype(np.longdouble)
    det = c11*c22-c12*c12
    stable = bool(min(c11, c22, c66) > 0 and det > 0)
    if stable:
        young, poisson = directional_moduli_2d(c, theta)
        s11, s22, s12, s66 = c22/det, c11/det, -c12/det, 1/c66
        # In t=cos(theta)^2 the longitudinal compliance is a quadratic.
        aa = s11+s22-2*s12-s66
        bb = 2*s12+s66-2*s22
        candidates = [0.0, float(np.pi/2)]
        if aa != 0:
            t = -bb/(2*aa)
            if 0 < t < 1:
                candidates.append(float(np.arccos(np.sqrt(t))))
        candidates = np.sort(candidates)
        values, _ = directional_moduli_2d(c, candidates)
        ymin, ymax = float(np.min(values)), float(np.max(values))
        # Public tie rule: relative 1e-10, including isotropic roundoff.
        lo = np.flatnonzero(np.abs(values-ymin) <= 1e-10*abs(ymin))[0]
        hi = np.flatnonzero(np.abs(values-ymax) <= 1e-10*abs(ymax))[0]
        tmin, tmax = float(candidates[lo]), float(candidates[hi])
        ratio = float(ymax/ymin)
    else:
        young = np.full(theta.shape, np.nan)
        poisson = young.copy()
        ymin = ymax = ratio = tmin = tmax = float('nan')
    return {'stiffness_npm': c, 'born_stable': stable,
            'young_npm': young, 'poisson': poisson,
            'young_min_npm': ymin, 'young_max_npm': ymax,
            'anisotropy_ratio': ratio,
            'theta_young_min_rad': tmin, 'theta_young_max_rad': tmax}
