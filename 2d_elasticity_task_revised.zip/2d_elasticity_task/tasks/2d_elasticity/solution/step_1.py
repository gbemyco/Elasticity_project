import numpy as np

def elastic_energy_density_2d(strains, stiffness_npm):
    """Areal harmonic energy; negative curvature is permitted in this diagnostic."""
    e = np.asarray(strains, dtype=float)
    c = np.asarray(stiffness_npm, dtype=float)
    if e.ndim != 2 or e.shape[1] != 3 or not np.all(np.isfinite(e)) or np.any(np.abs(e) > 0.03):
        raise ValueError("Invalid strains")
    if c.shape != (4,) or not np.all(np.isfinite(c)):
        raise ValueError("Invalid stiffness")
    x, y, g = e.T
    return (c[0]*x*x/2 + c[1]*y*y/2 + c[2]*x*y + c[3]*g*g/2) / 16.02176634
