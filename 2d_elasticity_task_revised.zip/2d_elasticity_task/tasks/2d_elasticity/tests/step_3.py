
# --- test case 0 ---
import numpy as np

# Isotropic elasticity: rotational invariance
E0, nu0 = 200.0, 0.25
C = np.array([E0/(1-nu0**2), E0/(1-nu0**2),
              nu0*E0/(1-nu0**2), E0/(2*(1+nu0))])

angles = np.array([0, 0.17, np.pi/4, 1.1, np.pi/2, np.pi])
E, nu = directional_moduli_2d(C, angles)

assert np.allclose(E, E0, rtol=1e-9, atol=1e-8)
assert np.allclose(nu, nu0, rtol=1e-9, atol=1e-10)


# --- test case 1 ---
import numpy as np

# Anisotropic directional Young's modulus and Poisson ratio
C = np.array([160., 90., 25., 45.])
angles = np.array([0, np.pi/6, np.pi/4, np.pi/3, np.pi/2])

expected_E = [153.05555556, 126.78811122, 108.86937431,
              95.89557650, 86.09375]
expected_nu = [0.2777777777777778, 0.24065196548418022,
               0.2096597145993414, 0.18201595358955772, 0.15625]

E, nu = directional_moduli_2d(C, angles)

assert np.allclose(E, expected_E, rtol=1e-9, atol=1e-8)
assert np.allclose(nu, expected_nu, rtol=1e-9, atol=1e-10)


# --- test case 2 ---
import numpy as np

# Near-instability: small positive Born determinant
C = np.array([100., 80., 89., 20.])
angles = np.array([0, np.pi/4, np.pi/2])

expected_E = [0.9875, 53.10924369747895, 0.79]
expected_nu = [1.1125, 0.32773109243697296, 0.89]

E, nu = directional_moduli_2d(C, angles)

assert np.allclose(E, expected_E, rtol=1e-9, atol=1e-8)
assert np.allclose(nu, expected_nu, rtol=1e-9, atol=1e-10)


# --- test case 3 ---
import numpy as np

# Born-unstable stiffness must raise ValueError
C = np.array([100., 50., 80., 20.])

try:
    directional_moduli_2d(C, [0, np.pi/4])
except ValueError:
    pass
else:
    raise AssertionError("Unstable stiffness must raise ValueError")


# --- test case 4 ---
import numpy as np

# Auxetic isotropic material: negative Poisson ratio
E0, nu0 = 110.0, -0.30
C = np.array([E0/(1-nu0**2), E0/(1-nu0**2),
              nu0*E0/(1-nu0**2), E0/(2*(1+nu0))])

angles = np.array([0, 0.23, np.pi/4, 1.28, np.pi/2])
E, nu = directional_moduli_2d(C, angles)

assert E.shape == nu.shape == angles.shape
assert np.allclose(E, E0, rtol=1e-9, atol=1e-8)
assert np.allclose(nu, nu0, rtol=1e-9, atol=1e-10)

# --- test case 5 ---
import numpy as np

# Malformed stiffness and nonfinite elastic constants are outside the contract.
for c in ([130., 85., 22.], [[130.,85.],[22.,48.]],
          [130.,np.nan,22.,48.], [130.,85.,22.,np.inf]):
    try:
        directional_moduli_2d(c, np.array([0.,np.pi/3]))
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid stiffness was accepted')

# --- test case 6 ---
import numpy as np

# Loading directions must be finite nonempty one-dimensional samples.
C = [140., 90., 25., 50.]
for angles in (np.array([]), np.array([[0.,np.pi/2]]), np.array([np.nan]), np.array([np.inf])):
    try:
        directional_moduli_2d(C, angles)
    except ValueError:
        pass
    else:
        raise AssertionError('Malformed angle samples were accepted')

# --- test case 7 ---
import numpy as np

# Born stability requires ALL positive normal and shear principal coefficients.
for c in ([-110.,-80.,20.,40.], [100.,70.,10.,0.], [100.,70.,10.,-1.], [100.,100.,100.,20.]):
    try:
        directional_moduli_2d(c, np.array([0.,np.pi/4]))
    except ValueError:
        pass
    else:
        raise AssertionError('Stiffness failed full Born positivity test')

# --- test case 8 ---
import numpy as np

# Almost-soft normal eigenmode: strict positive determinant is still stable.
C11, C22 = 120., 75.
C12 = np.sqrt(C11*C22*(1 - 1e-8))
C = np.array([C11, C22, C12, 40.])
assert 0 < C11*C22-C12*C12 < 0.001
angles = np.array([0.,np.pi/2])
E, nu = directional_moduli_2d(C, angles)
expected_E = np.array([C11-C12*C12/C22, C22-C12*C12/C11])
expected_nu = [C12/C22,C12/C11]
assert np.all(np.isfinite(E)) and np.all(np.isfinite(nu))
assert np.allclose(E, expected_E, rtol=1e-9, atol=1e-8)
assert np.allclose(nu, expected_nu, rtol=1e-9, atol=1e-10)

# --- test case 9 ---
import numpy as np

# Positive but very small shear modulus can dominate off-axis strain.
C = np.array([160., 90., 25., 1e-6])
E, nu = directional_moduli_2d(C, np.array([np.pi/4]))
det = C[0]*C[1]-C[2]**2
s11,s22,s12 = C[1]/det, C[0]/det, -C[2]/det
axial = (s11+s22+2*s12+1/C[3])/4
trans = (s11+s22+2*s12-1/C[3])/4
assert np.isclose(E[0], 1/axial, rtol=1e-9, atol=1e-8)
assert np.isclose(nu[0], -trans/axial, rtol=1e-9, atol=1e-10)

# --- test case 10 ---
import numpy as np
# Reflection, pi periodicity, and normal reciprocity are tensor identities.
C=np.array([260.,85.,-24.,31.]); a=np.array([-.37,.61,1.04,2.7])
E,nu=directional_moduli_2d(C,a)
Er,nur=directional_moduli_2d(C,-a)
Ep,nup=directional_moduli_2d(C,a+np.pi)
assert np.allclose(E,Er,rtol=2e-9,atol=2e-8)
assert np.allclose(E,Ep,rtol=2e-9,atol=2e-8)
assert np.allclose(nu,nur,rtol=2e-9,atol=2e-10)
assert np.allclose(nu,nup,rtol=2e-9,atol=2e-10)
Ex,nux=directional_moduli_2d(C,[0.,np.pi/2])
assert np.isclose(nux[0]/Ex[0],nux[1]/Ex[1],rtol=1e-9,atol=1e-10)

# --- test case 11 ---
import numpy as np
# Independently project the full strain tensor for mixed-sign coupling and large anisotropy.
C=np.array([920.,42.,-21.,8.]); a=np.array([-.9,.23,.83,2.2])
matrix=np.array([[C[0],C[2],0.],[C[2],C[1],0.],[0.,0.,C[3]]])
n=np.column_stack((np.cos(a),np.sin(a))); m=np.column_stack((-n[:,1],n[:,0]))
sigma=np.column_stack((n[:,0]**2,n[:,1]**2,n[:,0]*n[:,1]))
e=np.linalg.solve(matrix,sigma.T).T
T=np.zeros((len(a),2,2)); T[:,0,0]=e[:,0]; T[:,1,1]=e[:,1]
T[:,0,1]=T[:,1,0]=e[:,2]/2
axial=np.einsum('ni,nij,nj->n',n,T,n)
transverse=np.einsum('ni,nij,nj->n',m,T,m)
E,nu=directional_moduli_2d(C,a)
assert isinstance(E,np.ndarray) and isinstance(nu,np.ndarray)
assert E.shape==nu.shape==a.shape and E.dtype.kind==nu.dtype.kind=='f'
assert np.allclose(E,1/axial,rtol=1e-9,atol=1e-8)
assert np.allclose(nu,-transverse/axial,rtol=1e-9,atol=1e-10)

# --- test case 12 ---
import numpy as np
# 90-digit direct stress solves: almost-soft normal mode, well above floating zero.
C=np.array([1.0, 1.0, 0.9999999850988388, 0.5]); angles=np.array([0.0, 0.37, 1.5707963267948966])
E,nu=directional_moduli_2d(C,angles)
assert np.allclose(E,[2.9802322165650708e-08, 5.464948558629811e-08, 2.9802322165650708e-08],rtol=1e-9,atol=1e-8)
assert np.allclose(nu,[0.9999999850988388, 0.999999972675257, 0.9999999850988388],rtol=1e-9,atol=1e-10)

# --- test case 13 ---
import numpy as np
# Scale covariance: E scales with stiffness, while dimensionless Poisson does not.
C=np.array([155.,78.,23.,47.]); angles=np.array([-.2,.44,.91,3.2])
E,nu=directional_moduli_2d(C,angles)
E2,nu2=directional_moduli_2d(7*C,angles)
assert np.allclose(E2,7*E,rtol=2e-9,atol=8e-8)
assert np.allclose(nu2,nu,rtol=2e-9,atol=2e-10)
