
# --- test case 0 ---
import numpy as np

# Uniaxial and biaxial elastic energy
C = np.array([160., 90., 25., 45.])
strains = np.array([[0.01,0,0], [0,-0.02,0], [0.01,-0.01,0]])

expected = np.array([
    0.5*160*0.01**2,
    0.5*90*0.02**2,
    0.5*(160+90)*0.01**2 - 25*0.01**2
]) / 16.02176634

assert np.allclose(elastic_energy_density_2d(strains, C),
                   expected, rtol=1e-10, atol=1e-12)


# --- test case 1 ---
import numpy as np

# Pure shear: verifies engineering-shear convention
C = np.array([160., 90., 25., 45.])
strains = np.array([[0,0,0.02], [0,0,-0.02]])
expected = np.full(2, 0.5*45*0.02**2 / 16.02176634)

assert np.allclose(elastic_energy_density_2d(strains, C),
                   expected, rtol=1e-10, atol=1e-12)


# --- test case 2 ---
import numpy as np

# Valid strain boundary and invalid inputs
C = np.array([100., 100., 20., 40.])
result = elastic_energy_density_2d([[0.03,0,0]], C)

assert np.isclose(result[0], 0.5*100*0.03**2/16.02176634,
                  rtol=1e-10, atol=1e-12)

for invalid in ([[0.031,0,0]], [0.01,0,0]):
    try:
        elastic_energy_density_2d(invalid, C)
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid strains must raise ValueError")


# --- test case 3 ---
import numpy as np

# Zero-strain energy and strain-reversal symmetry
C = np.array([142., 86., -19., 33.])
strains = np.array([[0,0,0], [0.012,-0.009,0.011],
                    [-0.012,0.009,-0.011]])

expected = (
    0.5*142*0.012**2 + 0.5*86*0.009**2
    + (-19)*0.012*(-0.009) + 0.5*33*0.011**2
) / 16.02176634

result = elastic_energy_density_2d(strains, C)

assert result.shape == (3,)
assert np.isclose(result[0], 0.0, rtol=1e-9, atol=1e-12)
assert np.allclose(result[1:], expected, rtol=1e-10, atol=1e-12)

# --- test case 4 ---
import numpy as np

# Nonfinite strain or modulus cannot describe a finite harmonic energy.
C = np.array([140., 100., 25., 35.])
for e, c in [(np.array([[np.nan, 0., 0.]]), C),
             (np.array([[0., np.inf, 0.]]), C),
             (np.array([[0.01, 0., 0.]]), [140., np.nan, 25., 35.]),
             (np.array([[0.01, 0., 0.]]), [140., 100., np.inf, 35.])]:
    try:
        elastic_energy_density_2d(e, c)
    except ValueError:
        pass
    else:
        raise AssertionError('Nonfinite elasticity input was accepted')

# --- test case 5 ---
import numpy as np

# Four independent stiffness coefficients are required in a one-dimensional array.
for c in ([120., 70., 20.], [[120., 70.], [20., 35.]]):
    try:
        elastic_energy_density_2d([[0.01, 0., 0.]], c)
    except ValueError:
        pass
    else:
        raise AssertionError('Malformed stiffness shape was accepted')

# --- test case 6 ---
import numpy as np
# Empty batches preserve the batch axis; unstable curvature is not clipped.
assert elastic_energy_density_2d(np.empty((0,3)), [20.,30.,2.,-4.]).shape == (0,)
e=np.array([[0,0,.03],[.03,-.03,-.03],[-.03,.03,.03]])
c=np.array([-12.,-8.,3.,-4.])
expected=np.array([-0.0018,-0.0135,-0.0135])/16.02176634
r=elastic_energy_density_2d(e,c)
assert isinstance(r,np.ndarray) and r.dtype.kind=='f' and r.shape==(3,)
assert np.allclose(r,expected,rtol=1e-10,atol=1e-12)

# --- test case 7 ---
import numpy as np
# Harmonic homogeneity and independent work-conjugate stress at mixed loading.
e=np.array([[.004,-.006,.008],[-.005,.003,-.007]])
c=np.array([260.,130.,-37.,62.])
stress=np.column_stack((c[0]*e[:,0]+c[2]*e[:,1],
                        c[2]*e[:,0]+c[1]*e[:,1],c[3]*e[:,2]))
u=elastic_energy_density_2d(e,c)
assert u.shape==(2,)
assert np.allclose(u,.5*np.sum(stress*e,axis=1)/16.02176634,rtol=1e-10,atol=1e-12)
assert np.allclose(elastic_energy_density_2d(2*e,c),4*u,rtol=2e-10,atol=5e-12)
