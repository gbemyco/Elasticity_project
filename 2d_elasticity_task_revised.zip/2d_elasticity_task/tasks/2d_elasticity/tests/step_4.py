
# --- test case 0 ---
import numpy as np

# Stable anisotropic material: stiffness and directional extrema
C = np.array([160., 90., 25., 45.])
e = np.array([
    [0.01,0,0], [-0.01,0,0], [0,0.015,0], [0,-0.015,0],
    [0.01,0.01,0], [0.01,-0.01,0], [0,0,0.02], [0,0,-0.02]
])

x, y, g = e.T
X = np.column_stack((x**2/2, y**2/2, x*y, g**2/2))
angles = np.linspace(0, np.pi, 13)
r = analyze_elastic_2d(e, 166.4*(X @ C)/16.02176634, 166.4, angles)

keys = {"stiffness_npm", "born_stable", "young_npm", "poisson",
        "young_min_npm", "young_max_npm", "anisotropy_ratio",
        "theta_young_min_rad", "theta_young_max_rad"}

assert set(r) == keys and r["born_stable"] is True
assert r["young_npm"].shape == r["poisson"].shape == angles.shape
for name in ("young_min_npm", "young_max_npm", "anisotropy_ratio", "theta_young_min_rad", "theta_young_max_rad"):
    assert type(r[name]) is float
assert np.allclose(r["stiffness_npm"], C, rtol=1e-8, atol=1e-5)
assert np.isclose(r["young_min_npm"], 86.09375, rtol=1e-5, atol=1e-4)
assert np.isclose(r["young_max_npm"], 153.05555555555554, rtol=1e-5, atol=1e-4)
assert np.isclose(r["anisotropy_ratio"], 153.05555555555554/86.09375, rtol=1e-5, atol=1e-5)
assert np.isclose(r["theta_young_min_rad"], np.pi/2, rtol=1e-7, atol=1e-7)
assert np.isclose(r["theta_young_max_rad"], 0, rtol=1e-7, atol=1e-7)


# --- test case 1 ---
import numpy as np

# Born-unstable material: directional outputs must be NaN
C = np.array([100., 50., 80., 20.])
e = np.array([
    [0.01,0,0], [-0.01,0,0], [0,0.01,0], [0,-0.01,0],
    [0.01,0.01,0], [0.01,-0.01,0], [0,0,0.02], [0,0,-0.02]
])

x, y, g = e.T
X = np.column_stack((x**2/2, y**2/2, x*y, g**2/2))
angles = np.array([0, np.pi/4, np.pi/2])
r = analyze_elastic_2d(e, 120*(X @ C)/16.02176634, 120, angles)

assert r["born_stable"] is False
assert np.allclose(r["stiffness_npm"], C, rtol=1e-8, atol=1e-5)
assert r["young_npm"].shape == r["poisson"].shape == angles.shape
assert np.all(np.isnan(r["young_npm"]))
assert np.all(np.isnan(r["poisson"]))

for key in ("young_min_npm", "young_max_npm", "anisotropy_ratio",
            "theta_young_min_rad", "theta_young_max_rad"):
    assert np.isnan(r[key])


# --- test case 2 ---
import numpy as np

# Auxetic orthotropic material: negative Poisson ratio
C = np.array([130., 70., -14., 50.])
e = np.array([
    [0.01,0,0], [-0.012,0,0], [0,0.011,0], [0,-0.013,0],
    [0.012,0.008,0], [0.012,-0.008,0],
    [0,0,0.019], [0,0,-0.017], [0.009,-0.011,0.013]
])

x, y, g = e.T
X = np.column_stack((x**2/2, y**2/2, x*y, g**2/2))
angles = np.array([0, np.pi/2])
r = analyze_elastic_2d(e, 156*(X @ C)/16.02176634, 156, angles)

Ex = C[0] - C[2]**2/C[1]
Ey = C[1] - C[2]**2/C[0]

assert r["born_stable"] is True
assert np.allclose(r["stiffness_npm"], C, rtol=1e-8, atol=1e-5)
assert np.allclose(r["young_npm"], [Ex, Ey], rtol=1e-5, atol=1e-4)
assert np.allclose(r["poisson"], [-0.2, -14/130], rtol=1e-5, atol=1e-6)
assert np.isclose(r["anisotropy_ratio"], Ex/Ey, rtol=1e-5, atol=1e-5)

# --- test case 3 ---
import numpy as np

# Integrated function must reject invalid angular sampling independently.
e = np.array([[.01,0,0],[-.01,0,0],[0,.012,0],[0,-.012,0],
              [.01,.01,0],[.01,-.01,0],[0,0,.02],[0,0,-.02]])
x,y,g = e.T
C = np.array([160.,90.,25.,45.]); X = np.column_stack((x*x/2,y*y/2,x*y,g*g/2))
energies = 150*(X @ C)/16.02176634
for angles in (np.array([np.nan]), np.array([np.inf]), np.array([[0.,1.]]), np.array([])):
    try:
        analyze_elastic_2d(e, energies, 150., angles)
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid angles were accepted by integration')
    unstable_energy=150*(X @ np.array([-160.,-90.,25.,45.]))/16.02176634
    try:
        analyze_elastic_2d(e, unstable_energy, 150., angles)
    except ValueError:
        pass
    else:
        raise AssertionError('Unstable branch bypassed angle validation')


# --- test case 4 ---
import numpy as np

# Negative C66 or negative normal diagonals trigger unstable NaN branch.
e = np.array([[.01,0,0],[-.01,0,0],[0,.012,0],[0,-.012,0],
              [.01,.01,0],[.01,-.01,0],[0,0,.02],[0,0,-.02]])
x,y,g = e.T
X = np.column_stack((x*x/2,y*y/2,x*y,g*g/2))
angles = np.array([0.,np.pi/4,np.pi/2])
for C in (np.array([120.,90.,20.,-5.]), np.array([-120.,-90.,20.,45.])):
    r = analyze_elastic_2d(e, 150*(X @ C)/16.02176634, 150., angles)
    assert r['born_stable'] is False
    assert np.allclose(r['stiffness_npm'],C,rtol=1e-8,atol=1e-5)
    assert np.all(np.isnan(r['young_npm'])) and np.all(np.isnan(r['poisson']))
    for k in ('young_min_npm','young_max_npm','anisotropy_ratio',
              'theta_young_min_rad','theta_young_max_rad'):
        assert type(r[k]) is float and np.isnan(r[k])

# --- test case 5 ---
import numpy as np
e=np.array([[.012,0,0],[-.017,0,0],[0,.014,0],[0,-.019,0],
            [.01,.01,0],[.01,-.01,0],[0,0,.022],[0,0,-.016],
            [.009,-.011,.013]])
area=161.
C=np.array([200.0, 80.0, 20.0, 10.0]); angles=np.array([0.0, 1.5707963267948966])
matrix=np.array([[C[0],C[2],0.],[C[2],C[1],0.],[0.,0.,C[3]]])
energy=area*.5*np.sum(e*(e@matrix),axis=1)/16.02176634
r=analyze_elastic_2d(e,energy,area,angles)

# Rational continuous-compliance extremum: cos(theta)^2=14/31.
assert r['born_stable'] is True
assert np.allclose(r['stiffness_npm'],C,rtol=1e-8,atol=1e-5)
assert np.isclose(r['young_min_npm'],34.44444444444444,rtol=1e-5,atol=1e-4)
assert np.isclose(r['young_max_npm'],195.0,rtol=1e-5,atol=1e-4)
assert np.isclose(r['theta_young_min_rad'],0.8338611064174528,rtol=1e-7,atol=1e-7)
assert np.isclose(r['theta_young_max_rad'],0.0,rtol=1e-7,atol=1e-7)
assert np.isclose(r['anisotropy_ratio'],5.661290322580645,rtol=1e-5,atol=1e-5)

# --- test case 6 ---
import numpy as np
e=np.array([[.012,0,0],[-.017,0,0],[0,.014,0],[0,-.019,0],
            [.01,.01,0],[.01,-.01,0],[0,0,.022],[0,0,-.016],
            [.009,-.011,.013]])
area=161.
C=np.array([100.0, 70.0, 15.0, 200.0]); angles=np.array([0.0, 1.5707963267948966])
matrix=np.array([[C[0],C[2],0.],[C[2],C[1],0.],[0.,0.,C[3]]])
energy=area*.5*np.sum(e*(e@matrix),axis=1)/16.02176634
r=analyze_elastic_2d(e,energy,area,angles)

# Rational continuous-compliance extremum: cos(theta)^2=523/886.
assert r['born_stable'] is True
assert np.allclose(r['stiffness_npm'],C,rtol=1e-8,atol=1e-5)
assert np.isclose(r['young_min_npm'],67.75,rtol=1e-5,atol=1e-4)
assert np.isclose(r['young_max_npm'],160.87153881071268,rtol=1e-5,atol=1e-4)
assert np.isclose(r['theta_young_min_rad'],1.5707963267948966,rtol=1e-7,atol=1e-7)
assert np.isclose(r['theta_young_max_rad'],0.694606595062847,rtol=1e-7,atol=1e-7)
assert np.isclose(r['anisotropy_ratio'],2.3744876577226965,rtol=1e-5,atol=1e-5)

# --- test case 7 ---
import numpy as np
e=np.array([[.012,0,0],[-.017,0,0],[0,.014,0],[0,-.019,0],
            [.01,.01,0],[.01,-.01,0],[0,0,.022],[0,0,-.016],
            [.009,-.011,.013]])
area=161.
C=np.array([200.0, 80.0, 20.0, 10.0]); angles=np.array([0.31])
matrix=np.array([[C[0],C[2],0.],[C[2],C[1],0.],[0.,0.,C[3]]])
energy=area*.5*np.sum(e*(e@matrix),axis=1)/16.02176634
r=analyze_elastic_2d(e,energy,area,angles)

# Global science cannot depend on one sparse, oblique angle sample.
angles2=np.array([1.2,0.,.83,-.41,2.7,.13,.13])
r2=analyze_elastic_2d(e,energy,area,angles2)
for k in ('young_min_npm','young_max_npm','anisotropy_ratio'):
    assert np.isclose(r[k],r2[k],rtol=1e-8,atol=1e-8)
for k in ('theta_young_min_rad','theta_young_max_rad'):
    assert np.isclose(r[k],r2[k],rtol=1e-7,atol=1e-7)
assert r['young_npm'].shape==(1,) and r2['young_npm'].shape==angles2.shape
assert r['young_min_npm'] < min(r['young_npm'])-1

# --- test case 8 ---
import numpy as np
e=np.array([[.012,0,0],[-.017,0,0],[0,.014,0],[0,-.019,0],
            [.01,.01,0],[.01,-.01,0],[0,0,.022],[0,0,-.016],
            [.009,-.011,.013]])
area=161.

# Isotropic limit: all angles tie, canonical global directions must both be zero.
E0,nu0=180.,.2
C=np.array([E0/(1-nu0**2),E0/(1-nu0**2),nu0*E0/(1-nu0**2),E0/(2*(1+nu0))])
angles=np.array([.31,.89,2.2])
matrix=np.array([[C[0],C[2],0.],[C[2],C[1],0.],[0.,0.,C[3]]])
energy=area*.5*np.sum(e*(e@matrix),axis=1)/16.02176634
r=analyze_elastic_2d(e,energy,area,angles)
assert np.allclose(r['young_npm'],E0,rtol=1e-5,atol=1e-4)
assert np.allclose(r['poisson'],nu0,rtol=1e-5,atol=1e-6)
assert np.isclose(r['young_min_npm'],E0,rtol=1e-5,atol=1e-4)
assert np.isclose(r['young_max_npm'],E0,rtol=1e-5,atol=1e-4)
assert np.isclose(r['anisotropy_ratio'],1.,rtol=1e-5,atol=1e-5)
assert np.isclose(r['theta_young_min_rad'],0.,rtol=1e-7,atol=1e-7)
assert np.isclose(r['theta_young_max_rad'],0.,rtol=1e-7,atol=1e-7)

# --- test case 9 ---
import numpy as np
e=np.array([[.012,0,0],[-.017,0,0],[0,.014,0],[0,-.019,0],
            [.01,.01,0],[.01,-.01,0],[0,0,.022],[0,0,-.016],
            [.009,-.011,.013]])
area=161.
C=np.array([140.0, 95.0, -18.0, 24.0]); angles=np.array([-0.2, 0.43, 1.1, 2.8])
matrix=np.array([[C[0],C[2],0.],[C[2],C[1],0.],[0.,0.,C[3]]])
energy=area*.5*np.sum(e*(e@matrix),axis=1)/16.02176634
r=analyze_elastic_2d(e,energy,area,angles)

# Noise: validate at the returned fit, accounting for the whole error-propagation path.
energy=energy+1e-5*np.array([1,-1,.5,-.25,1.5,-.8,.2,-1.2,.3])
r=analyze_elastic_2d(e,energy,area,angles)
x,y,g=e.T; X=np.column_stack((x*x/2,y*y/2,x*y,g*g/2))
Q,R=np.linalg.qr(X,mode='reduced')
target=np.linalg.solve(R,Q.T@(energy*16.02176634/area))
assert np.allclose(r['stiffness_npm'],target,rtol=1e-5,atol=1e-4)
fitted=r['stiffness_npm']
matrix=np.array([[fitted[0],fitted[2],0.],[fitted[2],fitted[1],0.],[0.,0.,fitted[3]]])
n=np.column_stack((np.cos(angles),np.sin(angles)))
stress=np.column_stack((n[:,0]**2,n[:,1]**2,n[:,0]*n[:,1]))
v=np.linalg.solve(matrix,stress.T).T
axial=v[:,0]*n[:,0]**2+v[:,1]*n[:,1]**2+v[:,2]*n[:,0]*n[:,1]
transverse=v[:,0]*n[:,1]**2+v[:,1]*n[:,0]**2-v[:,2]*n[:,0]*n[:,1]
assert np.allclose(r['young_npm'],1/axial,rtol=1e-9,atol=1e-8)
assert np.allclose(r['poisson'],-transverse/axial,rtol=1e-9,atol=1e-10)
critical=np.array([r['theta_young_min_rad'],r['theta_young_max_rad']])
co,si=np.cos(critical),np.sin(critical)
v=np.linalg.solve(matrix,np.array([co*co,si*si,co*si])).T
q=v[:,0]*co*co+v[:,1]*si*si+v[:,2]*co*si
assert np.allclose([r['young_min_npm'],r['young_max_npm']],1/q,rtol=1e-9,atol=1e-8)
dense=np.linspace(0,np.pi/2,3001)
co,si=np.cos(dense),np.sin(dense)
v=np.linalg.solve(matrix,np.array([co*co,si*si,co*si])).T
Edense=1/(v[:,0]*co*co+v[:,1]*si*si+v[:,2]*co*si)
assert r['young_min_npm'] <= min(Edense)+(1e-8+1e-9*abs(min(Edense)))
assert r['young_max_npm'] >= max(Edense)-(1e-8+1e-9*abs(max(Edense)))
assert np.isclose(r['anisotropy_ratio'],r['young_max_npm']/r['young_min_npm'],rtol=1e-8,atol=1e-8)

# --- test case 10 ---
import numpy as np
e=np.array([[.012,0,0],[-.017,0,0],[0,.014,0],[0,-.019,0],
            [.01,.01,0],[.01,-.01,0],[0,0,.022],[0,0,-.016],
            [.009,-.011,.013]])
area=161.
C=np.array([160.0, 90.0, 25.0, 1e-06]); angles=np.array([0.0, 0.7853981633974483, 1.5707963267948966])
matrix=np.array([[C[0],C[2],0.],[C[2],C[1],0.],[0.,0.,C[3]]])
energy=area*.5*np.sum(e*(e@matrix),axis=1)/16.02176634
r=analyze_elastic_2d(e,energy,area,angles)

# Positive shear near the tested lower scale remains stable in the integrated workflow.
assert r['born_stable'] is True
assert np.all(np.isfinite(r['young_npm'])) and np.all(np.isfinite(r['poisson']))
assert r['young_min_npm']>0 and r['anisotropy_ratio']>1e7
assert np.isclose(r['theta_young_min_rad'],np.pi/4,rtol=1e-7,atol=1e-7)

# --- test case 11 ---
import numpy as np
# Integration must honor fitting validation, not silently repair or broadcast inputs.
e=np.array([[.01,0,0],[0,.012,0],[.01,.01,0],[.01,-.01,0],[0,0,.02]])
energy=np.ones(5); angles=np.array([.2,.7])
bad=e.copy(); bad[0,0]=np.nan
for strains,y,area in [(e,energy.reshape(5,1),120.),(e,energy[:4],120.),
                        (e,energy,0.),(e,energy,-120.),(e,energy,np.inf),
                        (bad,energy,120.),(e,np.full(5,np.nan),120.),
                        (e[:3],energy[:3],120.)]:
    try:
        analyze_elastic_2d(strains,y,area,angles)
    except ValueError:
        pass
    else:
        raise AssertionError('Integrated fit accepted invalid data')


# --- test case 12 ---
import numpy as np
# Decoupled pure-shear observations identify a small negative curvature with a fit-error margin.
e=np.array([[.01,0,0],[0,.012,0],[.01,.01,0],[.01,-.01,0],[0,0,.02]])
C=np.array([120.,90.,20.,-1e-3]); area=150.
x,y,g=e.T; X=np.column_stack((x*x/2,y*y/2,x*y,g*g/2))
r=analyze_elastic_2d(e,area*(X@C)/16.02176634,area,np.array([.31,.8]))
assert r['born_stable'] is False
assert np.allclose(r['stiffness_npm'],C,rtol=1e-8,atol=1e-5)
assert np.all(np.isnan(r['young_npm'])) and np.all(np.isnan(r['poisson']))
for key in ('young_min_npm','young_max_npm','anisotropy_ratio','theta_young_min_rad','theta_young_max_rad'):
    assert type(r[key]) is float and np.isnan(r[key])
