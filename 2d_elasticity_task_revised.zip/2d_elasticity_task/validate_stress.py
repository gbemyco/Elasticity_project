from pathlib import Path
import json
import os
import subprocess
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parent
BASE=ROOT
TASK=ROOT/'tasks/2d_elasticity'
runs=[]
for threads,seed in [(1,0),(1,271),(2,913)]:
    env=dict(os.environ)
    env.update({'OPENBLAS_NUM_THREADS':str(threads),'OMP_NUM_THREADS':str(threads),
                'MKL_NUM_THREADS':str(threads),'PYTHONHASHSEED':str(seed)})
    run=subprocess.run([sys.executable,str(BASE/'validate.py'),str(ROOT)],env=env,capture_output=True,text=True)
    if run.returncode:
        print(run.stdout); print(run.stderr); raise SystemExit(run.returncode)
    result=json.loads(run.stdout)
    (BASE/f'validation_threads{threads}_hash{seed}.json').write_text(run.stdout)
    runs.append({'threads':threads,'hash_seed':seed,'success':result['success'],
                 'seconds':result['seconds'],'reference_passed':result['correct']['solution.py']['passed'],
                 'alternative_passed':result['correct']['second_solution.py']['passed']})

def load(path):
    ns={}; exec(compile(path.read_text(),str(path),'exec'),ns); return ns
ref,alt=load(TASK/'solution.py'),load(TASK/'second_solution.py')
rng=np.random.default_rng(46371)
start=time.perf_counter()
stress=0
max_fit_difference=0.
max_directional_error=0.
for i in range(80):
    normal=rng.uniform(40,900,2)
    coupling=rng.uniform(-.85,.85)*np.sqrt(np.prod(normal))
    shear=10**rng.uniform(-6,2.7)
    c=np.array([*normal,coupling,shear])
    theta=rng.uniform(-4*np.pi,4*np.pi,17)
    er,nr=ref['directional_moduli_2d'](c,theta)
    ea,na=alt['directional_moduli_2d'](c,theta)
    assert np.allclose(er,ea,rtol=1e-9,atol=1e-8)
    assert np.allclose(nr,na,rtol=1e-9,atol=1e-10)
    e=rng.uniform(-.025,.025,(18,3)); area=float(rng.uniform(80,300))
    m=np.array([[c[0],c[2],0.],[c[2],c[1],0.],[0.,0.,c[3]]])
    energy=area*.5*np.sum(e*(e@m),axis=1)/16.02176634
    a=ref['analyze_elastic_2d'](e,energy,area,theta)
    b=alt['analyze_elastic_2d'](e,energy,area,theta)
    assert a['born_stable'] is True and b['born_stable'] is True
    assert np.allclose(a['stiffness_npm'],c,rtol=1e-8,atol=1e-5)
    assert np.allclose(b['stiffness_npm'],c,rtol=1e-8,atol=1e-5)
    # Each direction/extremum is checked at that method's own returned tensor.
    for answer,other in [(a,alt),(b,ref)]:
        ee,nn=other['directional_moduli_2d'](answer['stiffness_npm'],theta)
        assert np.allclose(answer['young_npm'],ee,rtol=1e-9,atol=1e-8)
        assert np.allclose(answer['poisson'],nn,rtol=1e-9,atol=1e-10)
        critical=np.array([answer['theta_young_min_rad'],answer['theta_young_max_rad']])
        ee,_=other['directional_moduli_2d'](answer['stiffness_npm'],critical)
        assert np.allclose(ee,[answer['young_min_npm'],answer['young_max_npm']],rtol=1e-9,atol=1e-8)
        dense=np.linspace(0,np.pi/2,1025)
        ee,_=other['directional_moduli_2d'](answer['stiffness_npm'],dense)
        assert answer['young_min_npm'] <= min(ee)+1e-8
        assert answer['young_max_npm'] >= max(ee)-1e-8
    max_fit_difference=max(max_fit_difference,float(max(abs(a['stiffness_npm']-b['stiffness_npm']))))
    max_directional_error=max(max_directional_error,float(max(abs(er-ea))))
    stress+=1

summary={'repeat_runs':runs,'stress_cases':stress,'stress_seed':46371,
         'stress_seconds':round(time.perf_counter()-start,4),
         'max_absolute_reference_alternative_stiffness_difference_npm':max_fit_difference,
         'max_absolute_same_tensor_young_difference_npm':max_directional_error,
         'python':sys.version.split()[0],'numpy':np.__version__}
(BASE/'repeat_stress_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
