"""Author-only admissible-error probes for the public Step 1 contract."""
from pathlib import Path
import json
import re

import numpy as np


ROOT = Path(__file__).parent / 'tasks' / '2d_elasticity'


def reference_function():
    namespace = {}
    source = ROOT / 'solution' / 'step_1.py'
    exec(compile(source.read_text(), str(source), 'exec'), namespace)
    return namespace['elastic_energy_density_2d']


def probe_function(base, mode):
    def candidate(strains, stiffness_npm, free_components=()):
        result = base(strains, stiffness_npm, free_components)
        values = np.asarray(strains, dtype=float)
        free = np.zeros(3, dtype=bool)
        free[np.asarray(free_components, dtype=int)] = True
        direction = -1.0 if mode.endswith('minus') else 1.0
        # A bounded smooth error may depend on ignored free input guesses.
        # It remains independently admissible at every call.
        phase = np.tanh(100*(values @ np.array([1.0, 2.0, -3.0])))
        if mode.startswith('free_strain'):
            result['relaxed_strains'] += direction * 0.8 * free * (
                1e-10 + 1e-9*np.abs(result['relaxed_strains']))
        elif mode.startswith('held_strain'):
            result['relaxed_strains'] += direction * 0.8 * (~free) * (
                1e-10 + 1e-9*np.abs(result['relaxed_strains']))
        elif mode.startswith('stress_'):
            result['stress_npm'] += direction * 0.8 * (
                1e-8 + 1e-9*np.abs(result['stress_npm']))
        elif mode.startswith('energy_'):
            result['energy_density_ev_ang2'] += direction * 0.8 * (
                1e-12 + 1e-10*np.abs(result['energy_density_ev_ang2']))
        else:
            if mode in ('smooth_strains', 'smooth_all_fields'):
                result['relaxed_strains'] += 0.8 * phase[:, None] * (
                    1e-10 + 1e-9*np.abs(result['relaxed_strains']))
            if mode in ('smooth_stress', 'smooth_all_fields'):
                result['stress_npm'] += 0.8 * phase[:, None] * (
                    1e-8 + 1e-9*np.abs(result['stress_npm']))
            if mode in ('smooth_energy', 'smooth_all_fields'):
                result['energy_density_ev_ang2'] += 0.8 * phase * (
                    1e-12 + 1e-10*np.abs(result['energy_density_ev_ang2']))
        return result
    return candidate


def validate():
    cases = re.split(r'^# --- test case \d+ ---\s*$',
                     (ROOT / 'tests' / 'step_1.py').read_text(), flags=re.M)[1:]
    modes = ['free_strain_plus', 'free_strain_minus',
             'held_strain_plus', 'held_strain_minus',
             'stress_plus', 'stress_minus', 'energy_plus', 'energy_minus',
             'smooth_strains', 'smooth_stress', 'smooth_energy',
             'smooth_all_fields']
    base = reference_function()
    results = {}
    for mode in modes:
        failures = []
        for index, case in enumerate(cases):
            namespace = {'elastic_energy_density_2d': probe_function(base, mode)}
            try:
                exec(compile(case, f'{mode}:case_{index}', 'exec'), namespace)
            except Exception as error:
                failures.append({'case': index, 'error': type(error).__name__,
                                 'message': str(error)})
        results[mode] = {'passed': len(cases)-len(failures), 'failed': failures}
    return {'cases_per_probe': len(cases), 'probes': results,
            'success': all(not result['failed'] for result in results.values())}


if __name__ == '__main__':
    result = validate()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['success'] else 1)
