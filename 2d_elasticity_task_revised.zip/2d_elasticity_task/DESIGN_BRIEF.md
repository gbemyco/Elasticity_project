# Scientific design

**Goal.** Recover an orthotropic monolayer's four areal stiffness constants from
small-strain total-energy differences, distinguish a stable material from a
saddle of the harmonic energy, and identify its softest and stiffest loading
directions. A sparse directional grid can miss the softest direction and give
an incorrect physical anisotropy ratio.

**Grounding.** Unstressed linear elasticity, work-conjugate engineering shear,
positive definiteness of the harmonic energy, and unweighted least squares.
All fixtures are synthetic continuum-model data in the same units and layout as
DFT energy–strain data; no actual DFT calculation or experimental measurement is
claimed. The constitutive model is specified in the visible prompts; the bibliography
is the exact user-supplied `tasks/2d_elasticity/source.md`.

**Substantive work.** Derive a correct shear-normalized energy; infer an
identifiable tensor without imposing stability on a possibly unstable fit;
project uniaxial stress through tensor strain; and find continuous directional
extrema, including an interior direction. The final step requires a continuous
analysis rather than selecting entries of the supplied angle array. Solvers
may use a polynomial stationarity calculation, a reliable root search, or
another method meeting the public accuracy and tie rules.

**Scope.** Four orthotropic in-plane constants; zero prestress; harmonic strains
up to 3%; area-based N/m units; full-rank physical regression designs with
column RMS at least 1e-6 and raw condition number at most 1000. Directional
verification includes ordinary, auxetic, anisotropic, small positive shear, and
nearly soft normal modes. Arbitrary overflow-scale inputs, nonlinear elasticity,
thermal effects, and a substrate's out-of-plane coupling are outside the
calibrated scientific accuracy claim.

**Independent verification.** Analytic isotropic and principal-axis identities,
rational oblique extrema, symmetry and scale covariance, QR fits and direct
stress-tensor solves, derivative-root searches, and a 90-digit author-side
stress solve for one near-soft target. Higher precision supports numerical
accuracy; the independent tensor derivation establishes the model itself.

**Packaging.** Same `tasks/2d_elasticity/` identity and four signatures as the
supplied task. The final dictionary still has nine keys, but its five summaries
now report continuous global extrema instead of sampled extrema. This change
is explicit in the visible prompt and regression tests.
