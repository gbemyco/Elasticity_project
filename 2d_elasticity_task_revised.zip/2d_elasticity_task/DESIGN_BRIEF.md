# Design brief

The scientific goal is to distinguish clamped elastic energy from the relaxed
response under mixed displacement and traction constraints, infer areal
orthotropic stiffness from DFT-like energy differences, and locate continuous
material soft directions. A sparse loading grid can miss an oblique minimum.

The supplied Herrero–Ramírez article grounds stress-controlled engineering
compliance and the relation between relaxation and energy curvature. This task
extends that reasoning to mixed constraints in an unstressed orthotropic
monolayer. It does not reproduce the paper's molecular dynamics, finite-temperature
membrane model, pressure spinodal, or per-layer bilayer normalization.

Step 1 minimizes a quadratic energy on its free strain subspace. It must
identify when a constrained minimum exists even if the full material is
unstable. Step 2 infers physical coefficients without changing the ordinary
least-squares objective or silently regularizing unstable curvature. Step 3
projects a work-conjugate engineering response into actual tensor strains.
Step 4 separates strict stability from conditioning and resolves continuous
extrema and reproducible ties at the returned fit.

The reference uses block elimination, constitutive basis-response SVD fitting,
and extended-precision compliance polynomials. The independent implementation
uses scalar square completion, an explicit physical regression with QR,
normal-eigenmode stress work, and derivative root search. Analytic examples and boundary
design eigenvalues provide evidence beyond agreement between the two programs.

The four-step folder identity remains `tasks/2d_elasticity`. The Step 1 signature
and output change to deliver the constrained calculation; all its dependent
implementations, scaffolds, tests, and contracts must match this revision.
