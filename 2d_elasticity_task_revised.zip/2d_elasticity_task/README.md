# 2D elasticity task

One scientific task with four steps, using the established
`tasks/2d_elasticity/` identity and authoring-template paths.
Scientific references, the independent solution, and graded tests use NumPy
only. No network, installation, or additional scientific package is required.

1. Resolve prescribed and freely relaxing engineering-strain components;
   return equilibrium strain, conjugate stress, and areal energy.
2. Infer [C11,C22,C12,C66] by unconstrained ordinary least squares.
3. Predict directional Young modulus and Poisson ratio through tensor mechanics.
4. Classify the returned fit and resolve continuous global elastic extrema.

`problem.yaml` contains the scientific assumptions, signatures, dependencies,
units, ranges, numerical conventions, accuracy guarantees, and output contracts.
Scaffolds are unimplemented. Per-step references and the complete `solution.py`
agree. `second_solution.py` uses independent numerical constructions.

Test cases are self-contained and numbered consecutively from zero. They use
only normal public calls and returned scientific results. No test accesses
function globals, unwraps an evaluator proxy, or modifies a function dependency.
The task has 90 cases: 21,24,16,19 per step and 10 whole-task cases.
Five named scientific mutants are declared: one per step and one whole task.

The reference-passing template's field names, relative source paths, consecutive
steps, test markers, NumPy-only imports, stable identity, and ordinary public
calls are retained. Its sparse test suite and sampled-extrema scientific scope
are expanded in this task. Step 1 accepts optional free components and returns
the specified three-key equilibrium dictionary; all interfaces match that change.

Local validation passes both implementations and all per-step references.
Both implementations also pass all 90 cases through call-only proxies. The five
scientific mutants and all-function no-op controls are rejected. The supplied
elasticity paper and preserved author source text are included in `source.md`.

Author-only runners and detailed execution records are separate from this
submission archive. The accompanying validation report describes numerical,
boundary, admissible-error, repeat-process, and high-precision checks. These
local results do not establish a new platform Oracle or quality approval.
