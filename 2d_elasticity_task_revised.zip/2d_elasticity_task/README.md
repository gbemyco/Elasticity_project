# 2D elasticity task — revised submission

Four evaluated steps, one stable folder identity: `tasks/2d_elasticity/`.
Scientific implementations and graded tests use NumPy only and run offline.

1. Minimize harmonic energy over free engineering-strain components; return
   equilibrium strain, conjugate stress, and areal energy.
2. Infer the four areal stiffness coefficients by ordinary least squares.
3. Predict directional Young modulus and Poisson ratio under uniaxial stress.
4. Classify the returned fitted tensor and determine continuous global extrema.

Step 1 now has signature
`elastic_energy_density_2d(strains, stiffness_npm, free_components=())` and
returns a three-key dictionary. The visible specification, scaffolds, references,
independent solution, dependencies, tests, and mutants all use this revision.
The final analysis signature and nine-key result remain unchanged.

The supplied elasticity article is cited in `source.md`; the original supplied
source text is preserved before the appended revision citation. Editor checkpoint
folders and the nested directory layers in the incoming archive were removed.
Only five scientific mutant files are included: one per step and one whole task.

Author documents: `DESIGN_BRIEF.md`, `COVERAGE.md`, `REVISION_NOTES.md`, and
`VALIDATION_REPORT.md`. `validation_results.json` records executed results.
Author-side runners can be invoked from this directory:

```sh
python validate.py
python validate_stress.py
python validate_fairness.py
python validate_step1_fairness.py
python validate_boundaries.py
```

These author runners use NumPy and Python's standard library; `validate.py`
also uses PyYAML to inspect the authoring schema. PyYAML is not a solution or
graded-test dependency. The separately performed high-precision author oracle
is recorded in `near_soft_results.json`; its runtime is not needed for the task.

Local verification does not establish platform parser acceptance, exploit or
difficulty-probe outcomes, reviewer acceptance, or final approval. Check the
upload preview. No identity mapping schema was supplied: no guessed mapping
or placeholder `problem_id` has been added. The original task folder is retained.
Author identity and affiliation metadata are retained from the supplied task.
