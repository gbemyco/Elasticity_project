# 2D elasticity task — revised

One task, four evaluated functions, unchanged identity `tasks/2d_elasticity/`.
The scientific workflow infers areal stiffness from energy–strain data and finds
continuous directional Young-modulus extrema, including oblique soft directions
that a sparse grid misses. The final function keeps its signature and nine keys;
its extrema/anisotropy now describe **all directions**, not just input samples.

Solutions require only `import numpy as np`, run offline, and perform no file access
or top-level computation. `steps/` contains unimplemented scaffolds; `solution/`
contains per-step references, and `solution.py` is the complete reference.
`second_solution.py` uses an independent QR fit, stress-tensor projection, and
derivative-root search for directional extrema.

Tests are self-contained zero-based parser cases. `problem.yaml` declares the
actual case counts and named mutants. Author validation is separate from the
platform's content, exploit, difficulty, rollout, and human-review checks.
See `DESIGN_BRIEF.md`, `COVERAGE.md`, `REVISION_NOTES.md`, and `VALIDATION_REPORT.md`
for the scientific rationale and the actual local validation results.

Author metadata is preserved from the supplied archive, not independently
authenticated. Confirm it and the current upload-panel schema, package support,
and size limits before submitting. No upload or platform approval is claimed.

## Author-side validation

With NumPy and PyYAML available, run `python3 validate.py` and
`python3 validate_stress.py` from this archive root. These scripts are separate
from submitted solution execution; they require no network or installation.
The task keeps its original author metadata and display identity.
