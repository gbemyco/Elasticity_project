# 2D elasticity task

One scientific task with four steps, using the established
`tasks/2d_elasticity/` identity and authoring-template paths.
Scientific references, the independent solution, and graded tests use NumPy
only. No network, installation, or additional scientific package is required.

1. Resolve prescribed and freely relaxing engineering-strain components;
   return equilibrium strain, conjugate stress, and areal energy.
2. Infer [C11,C22,C12,C66] by unconstrained ordinary least squares.
3. Predict directional Young modulus and Poisson ratio through tensor mechanics.
4. Classify the returned fit and resolve continuous global elastic extrema.

`problem.yaml` contains the scientific assumptions, signatures, dependencies,
units, ranges, numerical conventions, accuracy guarantees, and output contracts.
Scaffolds are unimplemented. Per-step references and the complete `solution.py`
agree. `second_solution.py` uses independent numerical constructions.

Test cases are self-contained and numbered consecutively from zero. They use
only normal public calls and returned scientific results. Two isolated Step 4 cases temporarily replace the supplied public fitting
dependency and verifies that the replacement was called. It requires a shared
public dependency binding between test and reference execution. No test accesses
function globals or unwraps an evaluator proxy.
The task has 100 cases: 25,25,17,23 per step and 10 whole-task cases.
Five named scientific mutants are declared: one per step and one whole task.

The reference-passing template's field names, relative source paths, consecutive
steps, test markers, NumPy-only imports, stable identity, and ordinary public
calls are retained. Its sparse test suite and sampled-extrema scientific scope
are expanded in this task. Step 1 accepts optional free components and returns
the specified three-key equilibrium dictionary; all interfaces match that change.

With shared public dependency bindings, local validation passes both
implementations and all per-step references.
Both implementations also pass all 100 cases through call-only proxies. The five
scientific mutants and all-function no-op controls are rejected. The supplied
elasticity paper and preserved author source text are included in `source.md`.

Author-only runners and detailed execution records are separate from this
submission archive. The accompanying validation report describes numerical,
boundary, admissible-error, repeat-process, and high-precision checks. These
local results do not establish a new platform Oracle or quality approval.

The scientific input domain comprises finite physical data from completed
calculations. Graded invalid-input cases address finite shape and range errors,
complex strains and angles, and incompatible mechanical boundary conditions.
Finite but unstable fitted tensors retain the specified NaN response outputs.
The coefficient and soft-normal calibration limits are tested.
Step 2 builds its raw design algebraically, independently of approximate Step 1
energy outputs. Step 4 propagates the reporting precision of fitted coefficients
through almost-soft mechanical responses and checks extremum values separately
from approximate extremum directions. Final-output perturbation controls pass.

This revision preserves every reference, independent implementation, scaffold,
scientific mutant, numerical tolerance, and stability convention. The binary64
roundoff allowance is stated as a fixed dimensionless comparison budget; it
does not enter the supplied physical observations. Step 1 covers complex free
guesses and empty complex-typed batches. The isotropic-source case checks the
returned fit's canonical directions on every run, without evaluator
introspection or dependency replacement.

The isolated isotropy fixture prescribes [96,96,48,24] directly through the
public fitting dependency. Its independent targets are E=72 N/m, nu=0.5,
unit anisotropy, and both canonical directions zero. Numeric comparisons use
the existing scientific tolerances. The platform's support for public dependency
replacement must be verified; the fixture fails explicitly if the replacement
cannot reach the reference in a separate execution namespace.

Additional coverage validates an out-of-range free strain guess and separately
checks the RMS threshold for all three normal design columns. Strict positive
admissibility is exercised below the calibrated accuracy endpoints: tiny normal
diagonals, tiny shear, and a positive normal determinant ratio near 1e-12.
Direct and prescribed-fit response cases require finite principal-axis outputs;
they do not extend the calibrated numerical accuracy guarantees.
